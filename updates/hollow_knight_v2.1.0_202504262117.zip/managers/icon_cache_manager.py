from kivy.cache import Cache


class IconCacheManager:
    def __init__(self):
        self.icon_cache = {}
        
    def get_icon(self, icon_id):
        """Retrieve icon from cache"""
        return self.icon_cache.get(icon_id)
        
    def add_icon(self, icon_id, icon_widget):
        """Add icon to cache"""
        self.icon_cache[icon_id] = icon_widget
        
    def remove_icon(self, icon_id):
        """Remove icon from cache"""
        self.icon_cache.pop(icon_id, None)
        
    def clear(self):
        """Clear all cached icons"""
        self.icon_cache.clear()
        Cache.remove('map_icons')