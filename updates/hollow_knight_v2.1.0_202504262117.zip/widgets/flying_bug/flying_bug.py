from kivy.uix.widget import Widget
from kivy.properties import ObjectProperty, ListProperty, BooleanProperty
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.image import Image
import random
from .sprite_animator import SpriteAnimator
from kivy.logger import Logger
from utils.resource_manager import ResourceManager
from utils.bug_counter import BugCounter

class FlyingBug(Widget):
    position = ListProperty([0, 0])
    is_squashed = BooleanProperty(False)
    on_squashed = ObjectProperty(None)  # Nuevo evento
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.speed_multiplier = 1.0
        self.size_hint = (None, None)
        # Use dp for consistent size across devices
        self._base_size = dp(40)
        self.size = (self._base_size, self._base_size)
        
        # Use ResourceManager for assets
        self.resource_manager = ResourceManager.get_instance()
        
        # Sprite setup with error handling
        try:
            self.sprite = Image(
                size_hint=(None, None),
                size=self.size,
                fit_mode='contain',
                
            )
            self.add_widget(self.sprite)
        except Exception as e:
            Logger.error(f"FlyingBug: Error creating sprite: {e}")
            return
            
        # Initialize animators with proper paths
        self._setup_animators()
        
        # Load sound through resource manager
        self.squash_sound = self.resource_manager.get_sound('assets/sounds/squash.mp3')
        
        # Bind position updates
        self.bind(pos=self._update_sprite_pos)
        
        # Start flying animation
        self.start_flying()
        
        # Bind touch events
        self.bind(on_touch_down=self.on_bug_touch)

        self.bug_counter = BugCounter.get_instance()

    def set_speed_multiplier(self, multiplier):
        self.speed_multiplier = multiplier    
        
        
    def _update_sprite_pos(self, *args):
        """Update sprite position when widget position changes"""
        self.sprite.pos = self.pos
        
    def start_flying(self):
        # Start sprite animation
        self.flight_animator.start(self.sprite)
        
        # Start movement animation
        Clock.schedule_once(self._create_random_movement, 0)
        
    def _setup_animators(self):
        fly_sprites = [f'assets/bugs/fly{i}.png' for i in range(1, 7)]
        squash_sprites = [f'assets/bugs/squash{i}.png' for i in range(1, 7)]
        
        # Verify resources exist
        fly_sprites = [self.resource_manager.get_image_path(p) for p in fly_sprites]
        squash_sprites = [self.resource_manager.get_image_path(p) for p in squash_sprites]
        
        # Filter out any None values from missing resources
        fly_sprites = [p for p in fly_sprites if p]
        squash_sprites = [p for p in squash_sprites if p]
        
        if not fly_sprites or not squash_sprites:
            Logger.error("FlyingBug: Missing sprite resources")
            return
            
        self.flight_animator = SpriteAnimator(fly_sprites, duration=0.1)
        self.squash_animator = SpriteAnimator(squash_sprites, duration=0.1, loop=False)

    def _create_random_movement(self, *args):
        try:
            if not self.parent:
                Logger.debug('FlyingBug: No parent widget found')
                return
            
            # Convert to integers
            parent_width = int(self.parent.width)
            parent_height = int(self.parent.height)
            margin = int(dp(20))
            
            # Ensure minimum size
            if parent_width <= (margin * 2) or parent_height <= (margin * 2):
                Logger.warning('FlyingBug: Parent widget too small for movement')
                return
            
            range_x = int(parent_width - self._base_size - margin)
            range_y = int(parent_height - self._base_size - margin)
            
            # Ensure minimum movement area
            range_x = max(range_x, dp(100))
            range_y = max(range_y, dp(100))
            
            current_x, current_y = self.pos
            
            # Generate 2-3 waypoints within parent bounds
            num_waypoints = random.randint(2, 3)
            waypoints = []
            
            for _ in range(num_waypoints):
                # Add some randomness to movement range
                x = min(max(random.randint(margin, range_x), 0), parent_width - self._base_size)
                y = min(max(random.randint(margin, range_y), 0), parent_height - self._base_size)
                waypoints.append((x, y))
            
            # Create sequence of animations through waypoints
            anim = None
            total_duration = 0
            
            for x, y in waypoints:
                # Calculate distance for this segment
                distance = ((x - current_x)**2 + (y - current_y)**2)**0.5
                
                # Apply speed multiplier to duration
                base_speed = random.uniform(80, 130)
                speed = base_speed * self.speed_multiplier
                duration = distance / speed
                
                # Create animation for this segment
                segment = Animation(
                    x=x, 
                    y=y, 
                    duration=duration
                )
                
                # Update current position for next segment
                current_x, current_y = x, y
                
                # Chain animations
                anim = segment if anim is None else anim + segment
                total_duration += duration
            
            # Add slight pause at end
            pause_duration = random.uniform(0.1, 0.5)
            anim += Animation(duration=pause_duration)
            
            # Start new sequence when complete
            anim.bind(on_complete=self._create_random_movement)
            anim.start(self)
            
        except Exception as e:
            Logger.error(f'FlyingBug: Movement error: {e}')
            import traceback
            Logger.error(f'FlyingBug: {traceback.format_exc()}')
            self.stop()
        
    def on_bug_touch(self, instance, touch):
        if self.collide_point(*touch.pos) and not self.is_squashed:
            self.squash()
            return True
        return False
            
    def squash(self):
        if not self.is_squashed:  # Prevent multiple squashes
            self.is_squashed = True
            
            # Only increment here, once
            self.bug_counter.increment()
            
            # Play sound and cleanup
            if self.squash_sound:
                self.squash_sound.play()
            
            self.flight_animator.stop()
            Animation.cancel_all(self)
            
            def on_squash_complete(*args):
                if self.parent:
                    self.parent.remove_widget(self)
            
            self.squash_animator.start(self.sprite, on_complete=on_squash_complete)