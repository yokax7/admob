from kivy.core.window import Window
from kivy.config import Config
from kivy.utils import platform
from kivy.logger import Logger

class WindowManager:
    DEFAULT_WIDTH = 1060
    DEFAULT_HEIGHT = 420

    @staticmethod
    def initialize_window():
        """Initialize basic window configuration"""
        try:
            # Basic graphics configuration
            Config.set('graphics', 'multisamples', '2')
            Config.set('graphics', 'maxfps', '60')

            if platform == "android":
                # Mobile settings
                Config.set('graphics', 'fullscreen', 'auto')
                Window.softinput_mode = "below_target"
            else:
                # Desktop settings
                Config.set('graphics', 'width', str(WindowManager.DEFAULT_WIDTH))
                Config.set('graphics', 'height', str(WindowManager.DEFAULT_HEIGHT))
                Config.set('graphics', 'resizable', '0')
                Config.set('graphics', 'fullscreen', '0')

            # Common window properties
            Window.clearcolor = (0, 0, 0, 1)
            Window.allow_screensaver = True

            # Apply changes
            Config.write()
            return True

        except Exception as e:
            Logger.error(f"WindowManager: Failed to initialize: {e}")
            return False

    @staticmethod
    def update_window():
        """Basic window update"""
        try:
            Window.canvas.ask_update()
        except Exception as e:
            Logger.error(f"WindowManager: Update failed: {e}")