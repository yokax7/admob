package org.yourpackage;

import android.app.Activity;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

public class ConsentHelper {
    private final Activity activity;
    private ConsentInformation consentInformation;

    public ConsentHelper(Activity activity) {
        this.activity = activity;
    }

    public void requestConsentInfoUpdate() {
        consentInformation = UserMessagingPlatform.getConsentInformation(activity);

        ConsentRequestParameters params = new ConsentRequestParameters.Builder()
                .setTagForUnderAgeOfConsent(false) // Cambia a true si tu app está dirigida a menores de edad
                .build();

        consentInformation.requestConsentInfoUpdate(
                activity,
                params,
                () -> {
                    // Consentimiento actualizado correctamente
                    if (consentInformation.isConsentFormAvailable()) {
                        loadAndShowConsentForm();
                    }
                },
                requestConsentError -> {
                    // Error al actualizar el consentimiento
                }
        );
    }

    private void loadAndShowConsentForm() {
        UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                activity,
                formError -> {
                    // El formulario de consentimiento se ha cerrado
                }
        );
    }
}