from kivy.event import EventDispatcher
from kivy.properties import NumericProperty

class BugCounter(EventDispatcher):
    count = NumericProperty(0)
    _instance = None
    
    @classmethod
    def get_instance(cls):
        if not cls._instance:
            cls._instance = BugCounter()
        return cls._instance
    
    def increment(self):
        self.count += 1
        return self.count
        
    def reset(self):
        self.count = 0

    def get_count(self):
        return self.count