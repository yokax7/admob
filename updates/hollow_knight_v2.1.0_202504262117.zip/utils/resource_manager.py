from kivy.core.audio import SoundLoader
from kivy.resources import resource_find
from kivy.logger import Logger

class ResourceManager:
    _instance = None
    _cache = {'images': {}, 'sounds': {}}
    
    @classmethod
    def get_instance(cls):
        if not cls._instance:
            cls._instance = ResourceManager()
        return cls._instance
    
    def get_image_path(self, path):
        if path not in self._cache['images']:
            full_path = resource_find(path)
            if not full_path:
                Logger.warning(f'Resource: Image not found: {path}')
                return None
            self._cache['images'][path] = full_path
        return self._cache['images'][path]
    
    def get_sound(self, path):
        if path not in self._cache['sounds']:
            try:
                sound = SoundLoader.load(resource_find(path))
                if sound:
                    self._cache['sounds'][path] = sound
                else:
                    Logger.warning(f'Resource: Sound not found: {path}')
                    return None
            except Exception as e:
                Logger.error(f'Resource: Error loading sound {path}: {e}')
                return None
        return self._cache['sounds'][path]
    
    def clear_cache(self):
        for sound in self._cache['sounds'].values():
            sound.unload()
        self._cache = {'images': {}, 'sounds': {}}