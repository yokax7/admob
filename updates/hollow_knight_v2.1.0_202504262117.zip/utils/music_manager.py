from kivy.core.audio import SoundLoader

class MusicManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(MusicManager, cls).__new__(cls)
            cls._instance.music = None
            cls._instance.sound_effects = {}
        return cls._instance
    
    def play_background_music(self, music_file='navegacion/sound.mp3'):
        if self.music is None:
            self.music = SoundLoader.load(music_file)
            if self.music:
                self.music.loop = True
                self.music.volume = 1.0
                self.music.play()
    
    def stop_music(self):
        if self.music:
            self.music.stop()
            self.music.unload()
            self.music = None
    
    def set_volume(self, volume):
        if self.music:
            self.music.volume = volume
        
    

music_manager = MusicManager()