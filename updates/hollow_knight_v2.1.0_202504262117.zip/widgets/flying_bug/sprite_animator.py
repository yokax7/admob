from kivy.clock import Clock


class SpriteAnimator:
    def __init__(self, sprite_paths, duration=0.1, loop=True):
        self.sprite_paths = sprite_paths
        self.duration = duration
        self.loop = loop
        self.current_frame = 0
        self.animation_event = None
        
    def start(self, sprite_widget, on_complete=None):
        self.sprite_widget = sprite_widget
        self.on_complete = on_complete
        self.current_frame = 0
        self._update_frame()
        
        if self.animation_event:
            self.animation_event.cancel()
            
        self.animation_event = Clock.schedule_interval(
            self._animate, 
            self.duration
        )
        
    def stop(self):
        if self.animation_event:
            self.animation_event.cancel()
            self.animation_event = None
            
    def _animate(self, dt):
        self.current_frame = (self.current_frame + 1) % len(self.sprite_paths)
        
        if not self.loop and self.current_frame == 0:
            self.stop()
            if self.on_complete:
                self.on_complete()
            return False
            
        self._update_frame()
        
    def _update_frame(self):
        self.sprite_widget.source = self.sprite_paths[self.current_frame]