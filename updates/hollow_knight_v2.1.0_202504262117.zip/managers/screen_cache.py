from collections import OrderedDict
import time

class ScreenCache:
    def __init__(self, max_screens=5):
        self.cache = OrderedDict()
        self.max_screens = max_screens
        
    def add_screen(self, screen_name, timestamp):
        """Adds or updates a screen in the cache with timestamp"""
        self.cache[screen_name] = timestamp
        self._cleanup()
        
    def get_screen_timestamp(self, screen_name):
        """Gets the timestamp of a cached screen"""
        return self.cache.get(screen_name)
        
    def update_timestamp(self, screen_name):
        """Updates timestamp of existing screen"""
        if screen_name in self.cache:
            self.cache[screen_name] = time.time()
        
    def remove_oldest(self, current_screen, protected_screens=None):
        """Removes oldest screen if cache is full"""
        if not protected_screens:
            protected_screens = {'loading'}
            
        if len(self.cache) >= self.max_screens:
            oldest = min(self.cache.items(), key=lambda x: x[1])
            if (oldest[0] != current_screen and 
                oldest[0] not in protected_screens):
                screen_name = oldest[0]
                del self.cache[screen_name]
                return screen_name
        return None
        
    def _cleanup(self):
        """Removes old entries if cache exceeds max size"""
        while len(self.cache) > self.max_screens:
            self.cache.popitem(last=False)
            
    def clear(self):
        """Clears all cached screens"""
        self.cache.clear()