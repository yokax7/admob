APP_CONFIG = {
    'window_width': '1200',
    'window_height': '900'
}

SCREEN_CONFIG = {
    'screens': [
        {
            'name': 'main',
            'module': 'screens.main_screen',
            'class': 'MainScreen'
        },
        {
            'name': 'big_map',
            'module': 'screens.big_map_screen',
            'class': 'BigMapScreen'
        },
        {
            'name': 'info',
            'module': 'screens.info_screen',
            'class': 'InfoScreen'
        },
        {
            'name': 'amuletos',
            'module': 'screens.amulestos_screen2',
            'class': 'CharmsApp'
        }
    ]
}