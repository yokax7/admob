import threading
import requests
import json
from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from utils.language_manager import LanguageManager
from kivy.uix.scrollview import ScrollView

class VersionChecker:
    def __init__(self, current_version, github_version_url):
        self.current_version = current_version
        self.github_version_url = github_version_url
        self.language_manager = LanguageManager()

    def check_for_updates(self):
        # Usar un hilo separado para evitar bloqueos de la UI
        threading.Thread(target=self._check_for_updates).start()

    def _check_for_updates(self):
        try:
            latest_version = self.get_latest_version_from_github()
            if latest_version and self.is_update_available(latest_version):
                # Programar la llamada al método en el hilo principal
                Clock.schedule_once(lambda dt: self.show_update_dialog())
        except requests.RequestException:
            print("No se pudo conectar al servidor para verificar actualizaciones.")
        except Exception as e:
            print(f"Error inesperado al verificar actualizaciones: {e}")

    def get_latest_version_from_github(self):
        try:
            # La llamada a requests.get se hace aquí, dentro del hilo
            response = requests.get(self.github_version_url, timeout=5)
            response.raise_for_status()  # Lanza un error si la respuesta es un código de error
            data = response.json()
            return data.get("latest_version")
        except requests.RequestException as e:
            print(f"Error de red al obtener la versión: {e}")
        except json.JSONDecodeError:
            print("Error al decodificar la respuesta JSON del servidor.")
        except Exception as e:
            print(f"Error inesperado al obtener la versión: {e}")
        return None

    def is_update_available(self, latest_version):
        try:
            return latest_version > self.current_version
        except TypeError:
            print("Error al comparar versiones. Asegúrate de que los formatos sean correctos.")
            return False

    def show_update_dialog(self):
        update_text = self.language_manager.get_text('update')
        cancel_text = self.language_manager.get_text('menu')
        title_text = self.language_manager.get_text('update_title')

        # Main container
        content = BoxLayout(
            orientation='vertical',
            spacing=10,
            padding=20
        )

        # Improved label with better text handling
        label = Label(
            text=update_text,
            size_hint_y=None,
            height=self.get_text_height(update_text, 400),  # Dynamic height based on content
            halign='center',
            valign='middle',
            text_size=(400, None),
            markup=True,
            font_size='16sp'  # Consistent font size
        )
        
        # Force label to update its height based on text content
        label.bind(
            width=lambda *x: setattr(label, 'text_size', (label.width, None)),
            texture_size=lambda *x: setattr(label, 'height', label.texture_size[1])
        )

        # ScrollView with proper size and scroll behavior
        scroll_view = ScrollView(
            size_hint=(1, 0.8),
            do_scroll_x=False,
            do_scroll_y=True,
            bar_width=10,
            scroll_type=['bars', 'content']
        )
        
        # Container for the label inside ScrollView
        scroll_content = BoxLayout(
            orientation='vertical',
            size_hint_y=None
        )
        scroll_content.bind(minimum_height=scroll_content.setter('height'))
        scroll_content.add_widget(label)
        scroll_view.add_widget(scroll_content)
        
        # Add ScrollView to main container
        content.add_widget(scroll_view)

        # Button layout with consistent sizing
        buttons = BoxLayout(
            spacing=20,
            size_hint_y=None,
            height='50dp',
            padding=[20, 10]
        )

        cancel_button = Button(
            text=cancel_text,
            size_hint=(0.5, None),
            height='40dp',
            font_size='16sp'
        )
        
        # Create popup first so we can reference it in the button callback
        popup = Popup(
            title=title_text,
            size_hint=(0.9, 0.7),
            auto_dismiss=False
        )
        
        cancel_button.bind(on_press=popup.dismiss)
        buttons.add_widget(cancel_button)
        content.add_widget(buttons)

        popup.content = content
        popup.open()

    def get_text_height(self, text, width):
        """Calculate appropriate height for text content"""
        import math
        chars_per_line = width // 10  # Approximate characters per line
        num_lines = math.ceil(len(text) / chars_per_line)
        return num_lines * 20 + 50  # Base height plus padding

