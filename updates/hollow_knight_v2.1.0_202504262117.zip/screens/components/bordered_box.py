from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Color, Line

class BorderedBoxLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(1, 1, 1, 1)
            self.border = Line(width=1.5, rounded_rectangle=(self.x, self.y, self.width, self.height, 15))
        self.bind(pos=self.update_border, size=self.update_border)

    def update_border(self, *args):
        self.border.rounded_rectangle = (self.x, self.y, self.width, self.height, 15)