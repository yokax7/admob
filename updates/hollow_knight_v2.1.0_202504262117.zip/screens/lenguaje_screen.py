from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from widgets.HollowKnightButton import HollowKnightButton
from utils.language_manager import language_manager
from kivy.app import App
from kivy.metrics import dp
from kivy.clock import Clock

class LanguageSelectionScreen(Screen):
    def __init__(self, **kwargs):
        super(LanguageSelectionScreen, self).__init__(**kwargs)
        self.language_manager = language_manager
        self.buttons = []  # Lista para almacenar los botones de idioma
        self.setup_ui()
        
    def setup_ui(self):
        # Background
        background = Image(
            source='navegacion/lenguaje_fondo.webp',
            fit_mode='contain',
            size_hint=(1, 1)
        )
        background.color = (1, 1, 1, 0.45)
        self.add_widget(background)
        
        # Main layout
        main_layout = BoxLayout(orientation='vertical', size_hint=(1, 1))
        
        # Header layout
        header_layout = self.create_header()
        main_layout.add_widget(header_layout)
        
        # Middle layout
        middle_layout = self.create_middle()
        main_layout.add_widget(middle_layout)
        
        # Bottom layout
        bottom_layout = self.create_bottom()
        main_layout.add_widget(bottom_layout)
        
        self.add_widget(main_layout)
        
        # Inicializar los textos
        self.update_language()

    def create_header(self):
        # Header layout
        header_layout = BoxLayout(
            orientation='vertical', 
            size_hint=(1, 0.25),  # Aumentamos el tamaño del header para dar más espacio
            spacing=dp(10),  # Espaciado entre los widgets
            padding=[dp(10), dp(20), dp(10), dp(10)]  # Padding: izquierda, arriba, derecha, abajo
        )
        
        # Logo
        logo = Image(
            source='logos/logo_png.png', 
            size_hint=(0.25, None),
            size=(dp(80), dp(80)),
            pos_hint={'center_x': 0.5}  # Centrar el logo horizontalmente
        )
        
        # Welcome label
        self.welcome_label = Label(
            font_size=dp(24),  # Reducimos el tamaño de la fuente para que quepa mejor
            size_hint=(1, 0.8),  # Ajustamos el tamaño del label dentro del header
            halign='center',  # Alineación horizontal centrada
            valign='middle',  # Alineación vertical centrada
            font_name='fonts/TrajanPro-Bold.otf',
            text_size=(self.width * 0.9, None)  # Ajustamos el ancho del texto al 90% del ancho del label
        )
        self.welcome_label.bind(size=self.welcome_label.setter('text_size'))  # Ajustar el texto al tamaño del label
        
        header_layout.add_widget(logo)
        header_layout.add_widget(self.welcome_label)
    
        return header_layout

    def create_middle(self):
        # Middle layout
        middle_layout = BoxLayout(orientation='vertical', size_hint=(1, 0.6))
        
        # Instruction label
        self.instruction_label = Label(
            font_size=dp(18), 
            size_hint=(1, 0.2), 
            halign='center', 
            font_name='fonts/TrajanPro-Bold.otf'
        )
        self.instruction_label.bind(size=self.instruction_label.setter('text_size'))
        
        # Language grid - changed to 3 columns and adjusted size/spacing
        language_grid = GridLayout(
            cols=3,  # Changed from 2 to 3 columns
            spacing=dp(5),  # Reduced spacing
            padding=dp(5),  # Reduced padding
            size_hint=(0.9, 0.6),  # Increased width
            pos_hint={'center_x': 0.5}
        )
        
        # List of languages with their respective flags and names
        self.languages = [
            {'flag': 'logos/venezuela.png', 'code': 'es', 'name': 'spanish'},
            {'flag': 'logos/estados-unidos.png', 'code': 'en', 'name': 'english'},
            {'flag': 'logos/brasil.png', 'code': 'pt', 'name': 'portuguese'},
            {'flag': 'logos/rusia.png', 'code': 'ru', 'name': 'Россия'},
            # Now you can add more languages and they'll flow into new rows
        ]
        
        # Add language buttons to the grid
        for lang in self.languages:
            # Container for flag and button
            container = BoxLayout(orientation='horizontal', size_hint=(1, None), height=dp(45))
            
            flag = Image(
                source=lang['flag'], 
                size_hint=(0.2, 1),  # Adjusted size ratio
                allow_stretch=True
            )
            
            button = HollowKnightButton(
                size_hint=(0.8, 1),  # Adjusted size ratio
                on_press=self.change_language(lang['code'])
            )
            
            self.buttons.append(button)
            container.add_widget(flag)
            container.add_widget(button)
            language_grid.add_widget(container)
        
        middle_layout.add_widget(self.instruction_label)
        middle_layout.add_widget(language_grid)
        
        return middle_layout

    def create_bottom(self):
        # Bottom layout with adjusted size
        bottom_layout = BoxLayout(
            orientation='vertical', 
            size_hint=(0.5, 0.15),  # Increased width and height
            padding=[dp(20), dp(30)]
        )
        
        # Exit button with adjusted size
        self.exit_button = HollowKnightButton(
            size_hint=(0.6, None),  # Increased width
            height=dp(45),          # Increased height
            pos_hint={'center_x': 0.5},  # Center horizontally
            on_press=self.exit_app
        )
        bottom_layout.add_widget(self.exit_button)
        
        return bottom_layout

    def change_language(self, lang):
        def change(instance):
            # Start loading sequence
            app = App.get_running_app()
            
            def complete_loading(dt):
                # Set and save language
                self.language_manager.set_language(lang)
                self.language_manager.save_language()
                self.update_language()
                
                # Switch to main screen after resource loading
                app.screen_manager.load_screen('main')
            
            # Show loading screen first
            app.screen_manager.load_screen('loading')
            # Schedule completion after loading animation
            Clock.schedule_once(complete_loading, 1.5)
            
        return change

    def exit_app(self, instance):
        App.get_running_app().stop()

    def update_language(self):
        self.welcome_label.text = self.language_manager.get_text('welcome')
        self.instruction_label.text = self.language_manager.get_text('instruction')
        
        # Update button texts
        for button, lang in zip(self.buttons, self.languages):
            button.text = self.language_manager.get_text(lang['name'])
        
        # Add exit button text update
        self.exit_button.text = self.language_manager.get_text('exit_app')

    def on_enter(self):
        self.update_language()