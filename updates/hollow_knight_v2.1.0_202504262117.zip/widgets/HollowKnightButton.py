from kivy.uix.button import Button
from kivy.graphics import Color, RoundedRectangle
from kivy.properties import ListProperty, NumericProperty

class HollowKnightButton(Button):
    border_color = ListProperty([1, 1, 1, 1])
    background_color = ListProperty([0.05, 0.05, 0.2, 0.8])
    border_width = NumericProperty(3)
    corner_radius = NumericProperty(15)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_down = ''
        self.color = (0.8, 0.8, 0.8, 1)
        self.font_name = 'fonts/TrajanPro-Bold.otf'
        self.font_size = '18sp'
        self.bold = True
        self.bind(pos=self.update_canvas, size=self.update_canvas)
        self.bind(border_color=self.update_canvas, background_color=self.update_canvas,
                 border_width=self.update_canvas, corner_radius=self.update_canvas)

    def update_canvas(self, *args):
        self.canvas.before.clear()
        with self.canvas.before:
            # Borde
            Color(*self.border_color)
            RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[self.corner_radius]
            )

            # Fondo
            Color(*self.background_color)
            RoundedRectangle(
                pos=(self.x + self.border_width, self.y + self.border_width),
                size=(self.width - 2*self.border_width, self.height - 2*self.border_width),
                radius=[self.corner_radius - self.border_width]
            )

    def set_active(self, is_active):
        if is_active:
            self.background_color = [0.05, 0.05, 0.5, 0.4]  # Más transparente cuando está activo
            self.border_color = [1, 1, 1, 0.4]
        else:
            self.background_color = [0.05, 0.05, 0.2, 0.8]  # Opacidad normal cuando está inactivo
            self.border_color = [1, 1, 1, 1]