from kivy.uix.screenmanager import Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.scatter import Scatter
from kivy.uix.image import AsyncImage
from widgets.HollowKnightButton import HollowKnightButton
from kivy.uix.label import Label
from kivy.utils import get_color_from_hex
from utils.language_manager import language_manager
from kivy.animation import Animation
from utils.zone_data_loader import ZoneDataLoader



class ZoneScreen(Screen):
    def __init__(self, zone_image, zone_data, **kwargs):
        super(ZoneScreen, self).__init__(**kwargs)
        self.zone_loader = ZoneDataLoader()
        
        layout = FloatLayout(size_hint=(1,1))

        self.scatter = Scatter(do_scale=True, do_translation=True, do_rotation=False, size_hint=(1, 1), pos=(0, 0))
        self.add_widget(layout)
        
        self.image = AsyncImage(source=zone_image, fit_mode='contain')
        self.scatter.add_widget(self.image)
        layout.add_widget(self.scatter)

        self.back_button = HollowKnightButton(
            size_hint=(0.15, 0.1), 
            pos_hint={"x": 0.02, "y": 0}
        )
        self.back_button.bind(on_press=self.go_back)
        self.add_widget(self.back_button)

        self.bind(size=self.update_image_size)

        self.zone_label = Label(
            text="",
            size_hint=(None, None),
            pos_hint={"center_x": 0.5, "top": 0.9},
            font_size='50sp',
            color=get_color_from_hex('#FFFFFF'),
            font_name='fonts/TrajanPro-Bold.otf',
            halign='center'
        )
        self.add_widget(self.zone_label)
        
        self.zone_data = zone_data
        
        language_manager.bind(current_language=self.update_texts)
        
        self.update_texts()

    def on_enter(self):
        self.zone_label.opacity = 1
        self.update_texts()
        self.animate_label()

    def animate_label(self):
        anim = Animation(opacity=0.1, duration=6)
        anim.start(self.zone_label)

    def on_pre_leave(self):
        self.zone_label.opacity = 1
        self.update_texts()

    def update_texts(self, *args):
        self.update_zone_name()
        self.update_back_button()

    def update_zone_name(self, *args):
        current_language = language_manager.current_language
        try:
            zone_name = self.zone_data['zona'].get(current_language, "Unknown Zone")
            self.zone_label.text = zone_name
        except Exception as e:
            print(f"Error updating zone name: {e}")
            self.zone_label.text = "Unknown Zone"

    def update_back_button(self, *args):
        self.back_button.text = language_manager.get_text('exit')

    def update_image_size(self, *args):
        self.scatter.size = self.width, self.height
        self.image.size = self.width, self.height

    def go_back(self, instance):
        self.manager.current = 'main'