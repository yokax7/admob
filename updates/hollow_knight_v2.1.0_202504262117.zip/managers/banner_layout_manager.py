from kivy.uix.boxlayout import BoxLayout
from kivy.metrics import dp


class BannerLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (1, None)
        self.height = dp(50)  # Fixed banner height