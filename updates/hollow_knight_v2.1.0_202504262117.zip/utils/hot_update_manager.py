import os
import json
import zipfile
import threading
import requests
import shutil
from kivy.clock import Clock
from kivy.logger import Logger
from kivy.utils import platform
from kivy.app import App
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.progressbar import ProgressBar
from utils.language_manager import LanguageManager

class HotUpdateManager:
    """
    Maneja las actualizaciones automáticas (hot updates) de la aplicación
    sin necesidad de publicar en Google Play.
    """
    
    def __init__(self, current_version, update_info_url):
        """
        Inicializa el administrador de actualizaciones.
        
        :param current_version: La versión actual de la app (string)
        :param update_info_url: URL al archivo JSON con información de actualizaciones
        """
        self.current_version = current_version
        self.update_info_url = update_info_url
        self.language_manager = LanguageManager()
        self.update_info = None
        self.temp_dir = self._get_temp_dir()
        self._create_temp_dir()
        
    def _get_temp_dir(self):
        """Obtiene el directorio temporal adecuado según la plataforma"""
        if platform == 'android':
            from android.storage import app_storage_path
            base_path = app_storage_path()
            return os.path.join(base_path, 'updates')
        else:
            return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'updates')
    
    def _create_temp_dir(self):
        """Crea el directorio temporal si no existe"""
        if not os.path.exists(self.temp_dir):
            os.makedirs(self.temp_dir)
    
    def check_for_updates(self):
        """Inicia el proceso de verificación de actualizaciones en un hilo separado"""
        threading.Thread(target=self._check_for_updates_thread).start()
    
    def _check_for_updates_thread(self):
        """Proceso de verificación de actualizaciones que se ejecuta en segundo plano"""
        try:
            response = requests.get(self.update_info_url, timeout=10)
            response.raise_for_status()
            
            self.update_info = response.json()
            latest_version = self.update_info.get('latest_version')
            
            if self._is_update_available(latest_version):
                # Programar la UI en el hilo principal
                Clock.schedule_once(lambda dt: self._show_update_available_dialog(), 0)
        except Exception as e:
            Logger.error(f"HotUpdateManager: Error checking for updates: {e}")
    
    def _is_update_available(self, latest_version):
        """
        Comprueba si hay una actualización disponible comparando versiones
        
        :param latest_version: La última versión disponible en el servidor
        :return: True si hay actualización disponible, False en caso contrario
        """
        try:
            # Convertir versiones a tuplas para comparación (e.g., "1.2.3" -> (1, 2, 3))
            current = tuple(map(int, self.current_version.split('.')))
            latest = tuple(map(int, latest_version.split('.')))
            return latest > current
        except (TypeError, ValueError) as e:
            Logger.error(f"HotUpdateManager: Error comparing versions: {e}")
            return False
    
    def _show_update_available_dialog(self):
        """Muestra un diálogo informando sobre la actualización disponible"""
        title = self.language_manager.get_text('update_available') or "¡Actualización disponible!"
        message = self.language_manager.get_text('update_message') or f"Nueva versión {self.update_info.get('latest_version')} disponible. ¿Deseas actualizar ahora?"
        changelog = self.update_info.get('changelog', {}).get(self.language_manager.current_language, "Mejoras y correcciones")
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=20)
        
        # Mensaje principal
        main_label = Label(
            text=message,
            size_hint_y=None,
            height=100,
            halign='center',
            valign='middle',
            text_size=(400, None)
        )
        content.add_widget(main_label)
        
        # Notas de la versión
        if changelog:
            changelog_title = Label(
                text=self.language_manager.get_text('changelog') or "Notas de la versión:",
                size_hint_y=None,
                height=30,
                bold=True
            )
            content.add_widget(changelog_title)
            
            changelog_label = Label(
                text=changelog,
                size_hint_y=None,
                height=150,
                halign='left',
                valign='top',
                text_size=(400, None)
            )
            content.add_widget(changelog_label)
        
        # Botones
        buttons = BoxLayout(size_hint_y=None, height=50, spacing=20)
        
        cancel_btn = Button(
            text=self.language_manager.get_text('cancel') or "Cancelar",
            size_hint_x=0.5
        )
        
        update_btn = Button(
            text=self.language_manager.get_text('update_now') or "Actualizar ahora",
            size_hint_x=0.5
        )
        
        buttons.add_widget(cancel_btn)
        buttons.add_widget(update_btn)
        content.add_widget(buttons)
        
        popup = Popup(
            title=title,
            content=content,
            size_hint=(0.9, 0.8),
            auto_dismiss=False
        )
        
        cancel_btn.bind(on_press=popup.dismiss)
        update_btn.bind(on_press=lambda instance: self._start_update_process(popup))
        
        popup.open()
    
    def _start_update_process(self, parent_popup):
        """
        Comienza el proceso de actualización
        
        :param parent_popup: El popup padre que debe cerrarse
        """
        parent_popup.dismiss()
        
        # Crear popup de progreso
        progress_layout = BoxLayout(orientation='vertical', spacing=10, padding=20)
        status_label = Label(
            text=self.language_manager.get_text('downloading') or "Descargando actualización...",
            size_hint_y=None, 
            height=30
        )
        progress_bar = ProgressBar(max=100, value=0)
        
        progress_layout.add_widget(status_label)
        progress_layout.add_widget(progress_bar)
        
        progress_popup = Popup(
            title=self.language_manager.get_text('updating') or "Actualizando",
            content=progress_layout,
            size_hint=(0.9, 0.3),
            auto_dismiss=False
        )
        progress_popup.open()
        
        # Iniciar descarga en un hilo separado
        threading.Thread(
            target=self._download_update,
            args=(self.update_info.get('update_url'), progress_bar, status_label, progress_popup)
        ).start()
    
    def _download_update(self, update_url, progress_bar, status_label, popup):
        """
        Descarga la actualización desde el servidor
        
        :param update_url: URL de la actualización (archivo ZIP)
        :param progress_bar: Barra de progreso para actualizar
        :param status_label: Etiqueta para mostrar el estado
        :param popup: Popup para cerrar cuando termine
        """
        try:
            # Limpiar directorio temporal
            for item in os.listdir(self.temp_dir):
                path = os.path.join(self.temp_dir, item)
                if os.path.isdir(path):
                    shutil.rmtree(path)
                else:
                    os.remove(path)
            
            # Descargar el archivo
            local_filename = os.path.join(self.temp_dir, 'update.zip')
            
            with requests.get(update_url, stream=True) as r:
                r.raise_for_status()
                total_size = int(r.headers.get('content-length', 0))
                downloaded = 0
                
                with open(local_filename, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            # Actualizar la barra de progreso en el hilo principal
                            if total_size > 0:
                                progress = (downloaded / total_size) * 100
                                Clock.schedule_once(
                                    lambda dt, p=progress: setattr(progress_bar, 'value', p), 0
                                )
            
            # Actualizar estado e instalar la actualización
            Clock.schedule_once(
                lambda dt: setattr(status_label, 'text', 
                                  self.language_manager.get_text('installing') or "Instalando actualización..."),
                0
            )
            
            # Instalar la actualización
            self._install_update(local_filename, popup)
            
        except Exception as e:
            Logger.error(f"HotUpdateManager: Error downloading update: {e}")
            Clock.schedule_once(
                lambda dt: self._show_error_message(popup, str(e)),
                0
            )
    
    def _install_update(self, zip_path, popup):
        """
        Instala la actualización descomprimiendo el archivo ZIP
        
        :param zip_path: Ruta al archivo ZIP de actualización
        :param popup: Popup para cerrar cuando termine
        """
        try:
            app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            
            # Extraer archivos
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Extraer a un directorio temporal primero
                extract_dir = os.path.join(self.temp_dir, 'extracted')
                zip_ref.extractall(extract_dir)
                
                # Copiar archivos al directorio de la aplicación
                self._copy_recursive(extract_dir, app_dir)
            
            # Guardar la nueva versión
            with open(os.path.join(app_dir, 'current_version.json'), 'w') as f:
                json.dump({'version': self.update_info.get('latest_version')}, f)
            
            # Mostrar diálogo de éxito y reiniciar
            Clock.schedule_once(
                lambda dt: self._show_success_message(popup),
                0
            )
        except Exception as e:
            Logger.error(f"HotUpdateManager: Error installing update: {e}")
            Clock.schedule_once(
                lambda dt: self._show_error_message(popup, str(e)),
                0
            )
    
    def _copy_recursive(self, src, dst):
        """
        Copia archivos de forma recursiva, reemplazando los existentes
        
        :param src: Directorio fuente
        :param dst: Directorio destino
        """
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            
            if os.path.isdir(s):
                if not os.path.exists(d):
                    os.makedirs(d)
                self._copy_recursive(s, d)
            else:
                # No copiar archivos especiales como __pycache__
                if not item.startswith('__') and not item.endswith('.pyc'):
                    shutil.copy2(s, d)
    
    def _show_success_message(self, previous_popup):
        """
        Muestra mensaje de éxito y ofrece reiniciar la aplicación
        
        :param previous_popup: Popup anterior a cerrar
        """
        previous_popup.dismiss()
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=20)
        
        label = Label(
            text=self.language_manager.get_text('update_success') or "¡Actualización instalada con éxito! La aplicación debe reiniciarse para aplicar los cambios.",
            halign='center',
            valign='middle',
            text_size=(400, None),
            size_hint_y=None,
            height=100
        )
        
        restart_btn = Button(
            text=self.language_manager.get_text('restart_now') or "Reiniciar ahora",
            size_hint_y=None,
            height=50
        )
        
        content.add_widget(label)
        content.add_widget(restart_btn)
        
        popup = Popup(
            title=self.language_manager.get_text('success') or "¡Listo!",
            content=content,
            size_hint=(0.9, 0.4),
            auto_dismiss=False
        )
        
        restart_btn.bind(on_press=lambda instance: self._restart_app())
        
        popup.open()
    
    def _show_error_message(self, previous_popup, error_msg):
        """
        Muestra un mensaje de error
        
        :param previous_popup: Popup anterior a cerrar
        :param error_msg: Mensaje de error
        """
        previous_popup.dismiss()
        
        content = BoxLayout(orientation='vertical', spacing=10, padding=20)
        
        label = Label(
            text=f"{self.language_manager.get_text('update_error') or 'Error durante la actualización'}: {error_msg}",
            halign='center',
            valign='middle',
            text_size=(400, None),
            size_hint_y=None,
            height=100
        )
        
        close_btn = Button(
            text=self.language_manager.get_text('close') or "Cerrar",
            size_hint_y=None,
            height=50
        )
        
        content.add_widget(label)
        content.add_widget(close_btn)
        
        popup = Popup(
            title=self.language_manager.get_text('error') or "Error",
            content=content,
            size_hint=(0.9, 0.4),
            auto_dismiss=False
        )
        
        close_btn.bind(on_press=popup.dismiss)
        
        popup.open()
    
    def _restart_app(self):
        """Reinicia la aplicación para aplicar los cambios"""
        if platform == 'android':
            try:
                from jnius import autoclass
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                Intent = autoclass('android.content.Intent')
                currentActivity = PythonActivity.mActivity
                
                # Crear intent para reiniciar la app
                intent = Intent(currentActivity, PythonActivity)
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                currentActivity.stopService(intent)
                currentActivity.startActivity(intent)
                
                # Finalizar proceso actual
                JavaSystem = autoclass('java.lang.System')
                JavaSystem.exit(0)
            except Exception as e:
                Logger.error(f"HotUpdateManager: Error restarting app: {e}")
                # Método alternativo: simplemente detener la app
                App.get_running_app().stop()
        else:
            # En otras plataformas, simplemente detener la app
            App.get_running_app().stop()