from kivy.event import EventDispatcher
from kivy.properties import StringProperty
import json
import os
from kivy.utils import platform

class LanguageManager(EventDispatcher):
    current_language = StringProperty('en')
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(LanguageManager, cls).__new__(cls)
            cls._instance.register_event_type('on_language_change')
            cls._instance._current_language = 'en'
            cls._instance.translations = {}
            cls._instance._load_translations()
        return cls._instance

    def _load_translations(self):
        """Load translations from JSON files in the languages directory"""
        languages = ['en', 'es', 'pt','ru']
        for lang in languages:
            try:
                file_path = os.path.join('lenguajes', lang, 'ui.json')
                with open(file_path, 'r', encoding='utf-8') as f:
                    self.translations[lang] = json.load(f)
            except Exception as e:
                print(f"Error loading {lang} translations: {e}")
                # Set empty dict as fallback
                self.translations[lang] = {}

    def get_text(self, key):
        return self.translations[self.current_language].get(key, key)

    def set_language(self, lang):
        if lang in self.translations:
            self.current_language = lang
            self.dispatch('on_language_change')
        else:
            print(f"Language {lang} not supported")

    def on_language_change(self, *args):
        pass

    def get_language_file_path(self):
        if platform == 'android':
            from android.storage import app_storage_path
            return os.path.join(app_storage_path(), 'selected_language.json')
        else:
            return os.path.join(os.getcwd(), 'selected_language.json')

    def load_language(self):
        file_path = self.get_language_file_path()
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                data = json.load(f)
                self.set_language(data.get('language', 'en'))
            return True
        return False

    def save_language(self):
        file_path = self.get_language_file_path()
        with open(file_path, 'w') as f:
            json.dump({'language': self.current_language}, f)

language_manager = LanguageManager()