from kivy.uix.widget import Widget
from kivy.properties import NumericProperty
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.graphics import Color, Line, PushMatrix, PopMatrix, Rotate

class LoadingSpinner(Widget):
    angle = NumericProperty(0)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (dp(40), dp(40))
        self.pos_hint = {'center_x': .5, 'center_y': .5}
        
        with self.canvas:
            PushMatrix()
            self.rotation = Rotate(angle=self.angle, origin=self.center)
            Color(1, 1, 1, 0.8)
            self.line = Line(circle=(self.center_x, self.center_y, dp(15)), width=dp(2))
            PopMatrix()
            
        self.bind(pos=self._update_circle, size=self._update_circle)
        
    def _update_circle(self, *args):
        self.line.circle = (self.center_x, self.center_y, dp(15))
        self.rotation.origin = self.center
        
    def start(self):
        anim = Animation(angle=360, duration=1)
        anim.bind(on_complete=self._rotation_complete)
        anim.start(self)
        
    def _rotation_complete(self, *args):
        self.angle = 0
        Clock.schedule_once(lambda dt: self.start(), 0)