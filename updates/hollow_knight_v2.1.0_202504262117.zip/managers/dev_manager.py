from kivy.uix.textinput import TextInput
from kivy.metrics import dp
from kivy.logger import Logger
from utils.bug_counter import BugCounter

class DevManager:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = DevManager()
        return cls._instance

    def __init__(self):
        if DevManager._instance is not None:
            raise Exception("DevManager is a singleton")
        self.dev_mode = False
        self.dev_widgets = {}
        self.bug_counter = BugCounter.get_instance()

    def setup_dev_controls(self, screen_name, widget_parent, callback):
        # Create bug counter control
        bug_input = TextInput(
            text=str(self.bug_counter.get_count()),
            size_hint=(None, None), 
            size=(dp(100), dp(40)),
            pos_hint={'right': 0.98, 'top': 0.7},
            multiline=False,
            input_filter='int',
            opacity=0
        )
        
        def on_bug_count_change(instance):
            try:
                new_count = int(instance.text)
                if new_count >= 0:  # Validate positive numbers
                    self.bug_counter.count = new_count
                    Logger.info(f"DevManager: Bug count set to {new_count}")
                else:
                    instance.text = str(self.bug_counter.get_count())
            except ValueError:
                instance.text = str(self.bug_counter.get_count())
                
        bug_input.bind(on_text_validate=on_bug_count_change)
        widget_parent.add_widget(bug_input)
        self.dev_widgets[screen_name] = bug_input
        bug_input.disabled = not self.dev_mode
        
        # Update text when global count changes
        def update_text(instance, value):
            bug_input.text = str(value)
            
        self.bug_counter.bind(count=update_text)
        return bug_input

    def enable_dev_mode(self):
        """Activa el modo desarrollador"""
        self.dev_mode = True
        self._update_widgets()
        Logger.info("DevManager: Developer mode enabled")

    def disable_dev_mode(self):
        """Desactiva el modo desarrollador"""
        self.dev_mode = False
        self._update_widgets()
        Logger.info("DevManager: Developer mode disabled")

    def _update_widgets(self):
        """Actualiza todos los widgets dev"""
        for widget in self.dev_widgets.values():
            if widget:
                widget.opacity = 1.0 if self.dev_mode else 0
                widget.disabled = not self.dev_mode
                # Update text to current count
                if self.dev_mode:
                    widget.text = str(self.bug_counter.get_count())

    def cleanup_screen(self, screen_name):
        """Limpia los widgets de desarrollador cuando se cambia de pantalla"""
        if screen_name in self.dev_widgets:
            widget = self.dev_widgets[screen_name]
            # Unbind from bug counter
            self.bug_counter.unbind(count=widget.setter('text'))
            self.dev_widgets.pop(screen_name)