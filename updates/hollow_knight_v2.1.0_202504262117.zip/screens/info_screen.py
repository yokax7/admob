from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import AsyncImage
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.animation import Animation
from widgets.text_input_fixed import TextInputFixed
from widgets.HollowKnightButton import HollowKnightButton
import webbrowser
import requests
import json
from datetime import datetime
import os
import re
from utils.language_manager import LanguageManager


class InfoScreen(Screen):
    API_KEY = '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'
    SENDER_EMAIL = 'cthaeh7@gmail.com'
    RECEIVER_EMAIL = 'yokaax@gmail.com'
    SEND_LIMIT = 2
    SEND_HISTORY_FILE = "send_history.json"
    LINKS = {
        "license": 'https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1',
        "amuletos": 'https://hollowknight.fandom.com/es/wiki/Categor%C3%ADa:Amuletos',
        "licencia_wiki": 'https://creativecommons.org/licenses/by-sa/3.0/deed.es',
        "wiki": 'https://hollowknight.fandom.com/es/wiki/Hollow_Knight_Wiki',
        "steam": 'https://steamcommunity.com/id/demajen',
        "mapa": 'https://steamcommunity.com/sharedfiles/filedetails/?id=876122772'
    }

    def __init__(self, **kwargs):
        super(InfoScreen, self).__init__(**kwargs)
        self.language_manager = LanguageManager()
        layout = BoxLayout(orientation='horizontal')
        self.add_widget(layout)

        # Contenedor de información
        info_layout = BoxLayout(orientation='horizontal', size_hint=(1, 1))
        layout.add_widget(info_layout)

        version = Button(
            text='Hollow Knight Map V-1.0.0. Creative Commons BY-SA 4.0',
            size_hint=(0.01, 0.01),
            pos_hint={'x': 0.2, 'y': 0.04},
            background_color=(0, 0, 0, 1)
        )
        info_layout.add_widget(version)

        # Imágenes
        about_app = AsyncImage(source='about/app_info.png', size_hint=(0.4, 0.4), pos_hint={'x': 0.01, 'y': 0.5})
        legal_app = AsyncImage(source='about/app_legal.png', size_hint=(0.4, 0.4), pos_hint={'x': 0.3, 'y': 0.5})

        about_app.bind(on_touch_down=self.show_about_popup)
        legal_app.bind(on_touch_down=self.show_legal_popup)

        self.add_widget(about_app)
        self.add_widget(legal_app)

        anim = Animation(pos_hint={'y': 0.53}, duration=1)
        anim += Animation(pos_hint={'y': 0.5}, duration=1)
        anim.repeat = True
        anim.start(about_app)
        anim.start(legal_app)

        # Contenedor de contacto
        contact_layout = BoxLayout(orientation='vertical', padding=10, spacing=10, size_hint=(0.5, 1))
        layout.add_widget(contact_layout)

        # Título de contacto
        self.contact_title = Label(
            text=self.language_manager.get_text('contact'),
            font_size='30sp',
            bold=True,
            size_hint=(1, 0.1),
            height=40,
            font_name='fonts/TrajanPro-Bold.otf'
        )
        contact_layout.add_widget(self.contact_title)

        # Cuadros de texto para el email y nombre
        self.email_input = TextInputFixed(
            hint_text='Email', 
            size_hint=(1, 0.1), 
            height=40, 
            keyboard_mode='managed',
            multiline=False  # Asegura que sea una sola línea
        )
        self.email_input.bind(text=self.on_email_text)
        self.name_input = TextInputFixed(
            hint_text=self.language_manager.get_text('name'),
            size_hint=(1, 0.1),
            height=40,
            keyboard_mode='managed'
        )
        contact_layout.add_widget(self.email_input)
        contact_layout.add_widget(self.name_input)

        # Cuadro de texto para el mensaje
        self.message_input = TextInputFixed(
            hint_text=self.language_manager.get_text('message'),
            size_hint=(1, 0.4),
            keyboard_mode='managed'
        )
        contact_layout.add_widget(self.message_input)

        # Botón de enviar
        self.send_button = HollowKnightButton(
            text=self.language_manager.get_text('send'),
            size_hint=(1, 0.1),
            height=40
        )
        self.send_button.bind(on_press=self.send_email)
        contact_layout.add_widget(self.send_button)

        # Botón de regresar
        self.back_button = HollowKnightButton(
            text=self.language_manager.get_text('exit'),
            size_hint=(1, 0.1),
            height=40
        )
        self.back_button.bind(on_press=self.go_back)
        contact_layout.add_widget(self.back_button)

        # Agregar el logotipo de Discord
        self.discord_logo = AsyncImage(
            source='logos/discord_logo.png',
            size_hint=(0.2, 0.2),
            pos_hint={'x': 0.25, 'y': 0.22}
        )
        self.discord_logo.bind(on_touch_down=self.on_discord_touch_down)
        self.discord_logo.bind(on_touch_up=self.on_discord_touch_up)
        self.add_widget(self.discord_logo)

    def show_about_popup(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.show_popup_from_file("", "about_app.txt")

    def show_legal_popup(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.show_popup_from_file("Legal", "legal.txt")

    def load_info_json(self, language):
        try:
            file_path = os.path.join('lenguajes', language, 'info.json')
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading info.json for {language}: {e}")
            return {"title": "", "content": "Error loading content"}

    def show_popup_from_file(self, title, file_path):
        try:
            if file_path == "about_app.txt":
                # Load from JSON instead of text file
                current_lang = self.language_manager.current_language
                info_data = self.load_info_json(current_lang)
                title = info_data["title"]
                message = info_data["content"]
            else:
                # Keep existing logic for legal.txt
                with open(file_path, 'r', encoding='utf-8') as file:
                    message = file.read()
        except Exception as e:
            message = f"Error loading content: {str(e)}"

        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        scroll_view = ScrollView(size_hint=(1, 1))
        message_label = Label(
            text=message,
            markup=True,
            text_size=(700, None),
            size_hint_y=None,
            valign='top',
            halign='justify'
        )
        message_label.bind(
            size=lambda *args: setattr(message_label, 'text_size', (message_label.width, None))
        )
        message_label.bind(
            texture_size=lambda *args: setattr(message_label, 'height', message_label.texture_size[1])
        )
        scroll_view.add_widget(message_label)
        content.add_widget(scroll_view)

        close_button = HollowKnightButton(text=self.language_manager.get_text('exit'), size_hint=(0.4, 0.2), pos_hint={'center_x':0.5})
        close_button.bind(on_press=lambda *args: popup.dismiss())
        content.add_widget(close_button)

        popup = Popup(title=title, content=content, size_hint=(0.65, 0.8), auto_dismiss=False,background_color=(0, 0, 0, 0.9))
        
        # Bind the on_ref_press event to open_link method
        message_label.bind(on_ref_press=self.open_link)
        
        popup.open()

    def open_link(self, instance, value):
        if value in self.LINKS:
            webbrowser.open(self.LINKS[value])
        else:
            print(f"Link not found: {value}")

    def send_email(self, instance):
        user_email = self.email_input.text
        user_message = self.message_input.text
        user_name = self.name_input.text

        if not self.is_valid_email(user_email):
            self.show_popup("Error", "Por favor, introduce una dirección de correo electrónico válida.")
            return

        if not self.check_send_limit(user_email):
            self.show_popup("Límite Alcanzado", "Solo puedes enviar 2 mensajes por día.")
            return

        payload = {
            "sender": {"name": user_name, "email": self.SENDER_EMAIL},
            "to": [{"email": self.RECEIVER_EMAIL}],
            "subject": 'Contacto desde la App',
            "textContent": f"Correo del usuario: {user_email}\n\nMensaje:\n{user_message}"
        }

        try:
            response = requests.post(
                "https://api.sendinblue.com/v3/smtp/email",
                json=payload,
                headers={
                    "accept": "application/json",
                    "api-key": self.API_KEY,
                    "content-type": "application/json"
                }
            )
            if response.status_code == 201:
                self.show_popup("Mensaje Enviado", "Tu mensaje ha sido enviado exitosamente.")
                self.update_send_history(user_email)
            else:
                self.show_popup("Error", f"Error al enviar correo: {response.status_code} {response.text}")
        except Exception as e:
            self.show_popup("Error", f"Error al enviar correo: {e}")

    def check_send_limit(self, user_email):
        send_history = self.load_send_history()
        today = datetime.now().strftime("%Y-%m-%d")

        if user_email in send_history:
            user_history = send_history[user_email]
            if today in user_history and user_history[today] >= self.SEND_LIMIT:
                return False
        return True

    def update_send_history(self, user_email):
        send_history = self.load_send_history()
        today = datetime.now().strftime("%Y-%m-%d")

        if user_email in send_history:
            if today in send_history[user_email]:
                send_history[user_email][today] += 1
            else:
                send_history[user_email][today] = 1
        else:
            send_history[user_email] = {today: 1}

        self.save_send_history(send_history)

    def load_send_history(self):
        if os.path.exists(self.SEND_HISTORY_FILE):
            try:
                with open(self.SEND_HISTORY_FILE, "r") as f:
                    return json.load(f)
            except Exception as e:
                print(f"Error al cargar el historial de envíos: {e}")
        return {}

    def save_send_history(self, send_history):
        try:
            with open(self.SEND_HISTORY_FILE, "w") as f:
                json.dump(send_history, f)
        except Exception as e:
            print(f"Error al guardar el historial de envíos: {e}")

    def go_back(self, instance):
        self.manager.current = 'main'
        
    def on_email_text(self, instance, value):
        ## Validar el email cada vez que cambia
        if self.is_valid_email(value):
            instance.background_color = (1, 1, 1, 1)  # Blanco si es válido
        else:
            instance.background_color = (1, 0.8, 0.8, 1)  # Rojo claro si no es válid

    def is_valid_email(self, email):
        # Patrón básico para validar email
        pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return re.match(pattern, email) is not None

    def on_discord_touch_down(self, instance, touch):
         if instance.collide_point(*touch.pos):
            Animation(size_hint=(0.22, 0.22), duration=0.1).start(instance)

    def on_discord_touch_up(self, instance, touch):
        if instance.collide_point(*touch.pos):
            Animation(size_hint=(0.2, 0.2), duration=0.1).start(instance)
            self.open_discord(instance, touch)

    def open_discord(self, instance, touch):
        webbrowser.open('https://discord.gg/SVcvr6JF')

    def on_enter(self):
        # Actualizar todos los textos cuando se entra a la pantalla
        self.contact_title.text = self.language_manager.get_text('contact')
        self.name_input.hint_text = self.language_manager.get_text('name')
        self.message_input.hint_text = self.language_manager.get_text('message')
        self.send_button.text = self.language_manager.get_text('send')
        self.back_button.text = self.language_manager.get_text('exit')
