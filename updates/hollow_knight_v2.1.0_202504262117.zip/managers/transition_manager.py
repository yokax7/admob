from kivy.uix.screenmanager import FadeTransition, SlideTransition
from kivy.clock import Clock

class TransitionManager:
    _transitions = {}
    
    @classmethod
    def preload_transitions(cls):
        """Precarga todas las transiciones al inicio"""
        transitions = {
            'fade': FadeTransition(duration=0.3),
            'slide_left': SlideTransition(direction='left', duration=0.5),
            'slide_right': SlideTransition(direction='right', duration=0.5),
            'slide_up': SlideTransition(direction='up', duration=0.5),
            'slide_down': SlideTransition(direction='down', duration=0.5)
        }
        
        def _load_transition(key, transition):
            cls._transitions[key] = transition
            
        # Cargar transiciones de forma escalonada
        for i, (key, transition) in enumerate(transitions.items()):
            Clock.schedule_once(
                lambda dt, k=key, t=transition: _load_transition(k, t), 
                i * 0.1
            )
    
    @classmethod
    def get_transition(cls, type_name):
        """Obtiene una transición precargada"""
        if type_name not in cls._transitions:
            # Fallback a FadeTransition si no existe
            return FadeTransition(duration=0.5)
        return cls._transitions[type_name]