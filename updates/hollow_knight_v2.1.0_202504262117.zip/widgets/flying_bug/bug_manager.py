from kivy.clock import Clock
import random
from .flying_bug import FlyingBug
from kivy.logger import Logger
from kivy.metrics import dp
from utils.bug_counter import BugCounter

class BugManager:
    def __init__(self, parent_widget, max_bugs=3, spawn_interval=1.2):
        self.parent_widget = parent_widget
        self.max_bugs = max_bugs
        self.spawn_interval = spawn_interval
        self.active_bugs = []
        self.spawn_event = None
        self._is_active = False
        self.speed_multiplier = 1.0
        self.bug_counter = BugCounter.get_instance()
        # Bind to counter changes
        self.bug_counter.bind(count=self._on_count_changed)
        
    def start(self):
        if not self._is_active and not self.spawn_event:
            self._is_active = True
            self.spawn_event = Clock.schedule_interval(
                self._spawn_bug, 
                self.spawn_interval
            )
            
    def stop(self):
        self._is_active = False
        try:
            if self.spawn_event:
                self.spawn_event.cancel()
                self.spawn_event = None
            
            # Clean up bugs
            self._remove_all_bugs()
        except Exception as e:
            Logger.error(f"BugManager: Error in stop(): {e}")
            
    def _remove_all_bugs(self):
        for bug in self.active_bugs[:]:
            try:
                if bug.parent:
                    bug.parent.remove_widget(bug)
                # Ensure proper cleanup
                if hasattr(bug, 'flight_animator'):
                    bug.flight_animator.stop()
                if hasattr(bug, 'squash_animator'):
                    bug.squash_animator.stop()
            except Exception as e:
                Logger.error(f"BugManager: Error removing bug: {e}")
        self.active_bugs.clear()
            
    def _spawn_bug(self, dt):
        if not self._is_active or len(self.active_bugs) >= self.max_bugs:
            return
            
        try:
            # Check if parent widget exists and has size
            if not self.parent_widget or not self.parent_widget.size[0]:
                return
            
            # Create bug without connecting to increment_counter
            bug = FlyingBug()
            bug.set_speed_multiplier(self.speed_multiplier)
            
            # Remove this line since we're using global counter
            # if hasattr(self.parent_widget, 'increment_counter'):
            #     bug.on_squashed = self.parent_widget.increment_counter
                
            # Use parent widget bounds instead of Window
            parent_width = self.parent_widget.width
            parent_height = self.parent_widget.height
            
            # Convert floating point values to integers
            margin = int(dp(20))
            max_x = int(parent_width - bug.width - margin)
            max_y = int(parent_height - bug.height - margin)
            
            # Ensure we have valid ranges
            if max_x <= margin or max_y <= margin:
                Logger.warning('BugManager: Parent widget too small for bug spawning')
                return
            
            # Generate random positions with integer values
            x = random.randint(margin, max_x)
            y = random.randint(margin, max_y)
            
            # Ensure bug stays within bounds
            x = max(0, min(x, int(parent_width - bug.width)))
            y = max(0, min(y, int(parent_height - bug.height)))
            
            bug.pos = (x, y)
            self.active_bugs.append(bug)
            self.parent_widget.add_widget(bug)

            def on_squash(instance, value):
                if value:
                    self.parent_widget.increment_counter()
            
            bug.bind(is_squashed=self._on_bug_squashed)
            
        except Exception as e:
            Logger.error(f"BugManager: Error spawning bug: {e}")
            Logger.debug(f"BugManager: Parent size: {self.parent_widget.size if self.parent_widget else 'No parent'}")
            
    def _on_bug_squashed(self, bug, value):
        if value and bug in self.active_bugs:
            self.active_bugs.remove(bug)

    def _on_count_changed(self, instance, value):
        # Calculate new speed multiplier based on count
        # Every 3 bugs increases speed by 20%
        new_multiplier = 1.0 + (value // 2) * 0.35
        # Cap the maximum speed multiplier at 4.0
        new_multiplier = min(new_multiplier, 5.0)
        #Logger.info(f'BugManager: Updating speed multiplier to {new_multiplier:.2f} at count {value}')
        self.update_speed(new_multiplier)

    def update_speed(self, multiplier):
        self.speed_multiplier = multiplier
      #  Logger.info(f'BugManager: Applying speed multiplier {multiplier:.2f} to {len(self.active_bugs)} bugs')
        for bug in self.active_bugs:
            bug.set_speed_multiplier(multiplier)