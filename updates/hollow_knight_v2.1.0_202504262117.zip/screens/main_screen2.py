from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.animation import Animation
from widgets.npc_button import NPCButton
from data.npc_info import npc_info
from data.zones import zones
from kivy.uix.popup import Popup
from kivy.uix.image import AsyncImage
import threading
from kivy.clock import Clock
from screens.zone_screen import ZoneScreen
from utils.language_manager import language_manager  # Importar el gestor de idiomas
from utils.music_manager import music_manager
from widgets.settingbutton import SettingsButton
from managers.resource_manager import ResourceManager
from kivy.metrics import dp
from screens.components.bordered_box import BorderedBoxLayout
from kivy.uix.boxlayout import BoxLayout


class MainScreen(Screen):
    def __init__(self, **kwargs):
        super(MainScreen, self).__init__(**kwargs)
        self.language_manager = language_manager 
        self.npc_info = npc_info
        self.zones = zones
        self.current_npc_index = 0
        self.resource_manager = ResourceManager()
        self.resource_manager.preload_resources()
        
        self.setup_ui()
        threading.Thread(target=self.load_resources_in_background).start()

    def setup_ui(self):
        # Layout principal horizontal
        main_layout = BoxLayout(orientation='horizontal')
        
        # Layout izquierdo (15%)
        self.left_layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_x=0.10
        )
        
        # Sub-layouts izquierdos
        self.navigation_layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_y=0.75
        )
        
        self.settings_layout = BoxLayout(
            orientation='vertical',
            size_hint_y=0.25
        )
        
        # Layout central (70%)
        self.center_layout = BorderedBoxLayout(
            size_hint_x=0.8
        )
        
        # Layout derecho (15%)
        self.right_layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_x=0.10
        )
        
        # Agregar sub-layouts al layout izquierdo
        self.left_layout.add_widget(self.navigation_layout)
        self.left_layout.add_widget(self.settings_layout)
        
        # Agregar los tres layouts principales
        main_layout.add_widget(self.left_layout)
        main_layout.add_widget(self.center_layout)
        main_layout.add_widget(self.right_layout)
        
        # Crear label para coordenadas
        self.coords_label = Label(
            text="",
            size_hint=(None, None),
            size=(dp(200), dp(30)),
            pos_hint={'center_x': 0.5, 'y': 0},
            color=(1, 1, 1, 0.8)
        )
        
        self.add_widget(main_layout)
        self.add_widget(self.coords_label)
        self.setup_main_image()

    def setup_main_image(self):
        self.image = AsyncImage(
            size_hint=(1, 1),
            fit_mode='contain'
        )
        self.image.bind(on_touch_down=self.on_touch)
        self.image.bind(on_touch_move=self.update_coordinates)
        self.center_layout.add_widget(self.image)

    def update_coordinates(self, instance, touch):
        if self.image.collide_point(touch.x, touch.y):
            scale_x = self.image.width / self.image.texture_size[0]
            scale_y = self.image.height / self.image.texture_size[1]
            adjusted_x = (touch.x - self.image.x) / scale_x
            adjusted_y = (touch.y - self.image.y) / scale_y
            self.coords_label.text = f"Coordenadas: ({adjusted_x:.2f}, {adjusted_y:.2f})"

    def on_pre_enter(self):
        language = self.language_manager.current_language
        map_image_source = f'navegacion/navmap_{language}.png' if language in ['es', 'pt', 'en'] else 'navegacion/navmap.png'
        self.image.source = map_image_source
        music_manager.play_background_music()

    def load_resources_in_background(self):
        Clock.schedule_once(self.load_images_in_ui, 0.5)

    def load_images_in_ui(self, *args):
        self._setup_navigation_elements()
        self._setup_settings_button()
        self._setup_right_layout_icons()

    def _setup_navigation_elements(self):
        from kivy.uix.relativelayout import RelativeLayout
    
        # Create a RelativeLayout for circle and NPC button
        circle_container = RelativeLayout(
            size_hint=(0.8, 0.2),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # Flechas
        self.left_arrow = AsyncImage(
            source='navegacion/flecha_izquierda.png',
            size_hint=(0.8, 0.2),
            pos_hint={'center_x': 0.5, 'top': 1}
        )
        self.right_arrow = AsyncImage(
            source='navegacion/flecha_derecha.png',
            size_hint=(0.8, 0.2),
            pos_hint={'center_x': 0.5, 'y': 0}
        )
        
        # Círculo
        self.circle = AsyncImage(
            source='navegacion/Dream_Wielder.png',
            size_hint=(1, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # NPC Button
        self.npc_button = NPCButton(
            npc_image_path=self.npc_info[self.current_npc_index]['npc_image_path'],
            size_hint=(1, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # Add circle and NPC button to container
        circle_container.add_widget(self.circle)
        circle_container.add_widget(self.npc_button)  # Added last = appears on top
        
        # Agregar elementos al navigation layout
        self.navigation_layout.add_widget(self.left_arrow)
        self.navigation_layout.add_widget(circle_container)
        self.navigation_layout.add_widget(self.right_arrow)

        # Bind events
        self.left_arrow.bind(on_touch_down=self.show_previous_npc)
        self.right_arrow.bind(on_touch_down=self.show_next_npc)
        self.npc_button.bind(on_press=lambda instance: self.show_npc_popup(self.npc_info[self.current_npc_index]))
        

        # Animaciones
        self._start_circle_animation()
        self._setup_arrow_animations()

    def _start_circle_animation(self):
        anim = Animation(opacity=0.2, duration=2) + Animation(opacity=1, duration=2)
        anim.repeat = True
        anim.start(self.circle)

    def _setup_arrow_animations(self):
        def on_arrow_press(arrow, touch):
            if arrow.collide_point(*touch.pos):
                Animation(opacity=0.5, duration=0.1).start(arrow)

        def on_arrow_release(arrow, touch):
            if arrow.collide_point(*touch.pos):
                Animation(opacity=1, duration=0.2).start(arrow)

        for arrow in [self.left_arrow, self.right_arrow]:
            arrow.bind(on_touch_down=on_arrow_press)
            arrow.bind(on_touch_up=on_arrow_release)

    def _setup_settings_button(self):
        settings_button = SettingsButton()
        self.settings_layout.add_widget(settings_button)

    def _setup_right_layout_icons(self):
        # Big Map Icon
        self.big_map_image = AsyncImage(
            source='navegacion/Scroll_Map.png',
            size_hint=(1, 0.33)
        )
        
        # Boss Icon
        self.boss_image = AsyncImage(
            source='logos/boss_icon.png',
            size_hint=(1, 0.33)
        )
        
        # Amuletos Icon
        self.amuletos_image = AsyncImage(
            source='navegacion/anmuletos.png',
            size_hint=(1, 0.33)
        )
        
        # Bind events
        self.big_map_image.bind(on_touch_down=self.show_big_map)
        self.boss_image.bind(on_touch_down=self.show_boss_screen)
        self.amuletos_image.bind(on_touch_down=self.show_amuletos)
        
        # Add to right layout
        self.right_layout.add_widget(self.big_map_image)
        self.right_layout.add_widget(self.boss_image)
        self.right_layout.add_widget(self.amuletos_image)

        # Iniciar animaciones de hover
        for icon in [self.big_map_image, self.boss_image, self.amuletos_image]:
            self._setup_hover_animation(icon)

    def _setup_hover_animation(self, widget):
        def on_enter(w, touch):
            if w.collide_point(*touch.pos):
                Animation(size_hint=(1.1, 0.35), duration=0.3).start(w)

        def on_leave(w, touch):
            Animation(size_hint=(1, 0.33), duration=0.3).start(w)

        widget.bind(on_touch_down=on_enter)
        widget.bind(on_touch_up=on_leave)

    def show_previous_npc(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.current_npc_index = (self.current_npc_index - 1) % len(self.npc_info)
            self._update_npc_button()

    def show_next_npc(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.current_npc_index = (self.current_npc_index + 1) % len(self.npc_info)
            self._update_npc_button()

    def _update_npc_button(self):
        npc_info = self.npc_info[self.current_npc_index]
        self.npc_button.update_image(npc_info['npc_image_path'])
        Animation(opacity=0, duration=0.3).start(self.npc_button)
        Animation(opacity=1, duration=0.3).start(self.npc_button)

    def show_npc_popup(self, npc_info):
        popup = Popup(
            title=npc_info['name'],
            size_hint=(0.6, 0.8),
            background_color=(0, 0, 0, 1)
        )
        
        content = AsyncImage(
            source=npc_info['popup_image_path'],
            size_hint=(1, 1),
            fit_mode='contain'
        )
        
        popup.content = content
        popup.bind(
            on_touch_down=lambda instance, touch: 
            popup.dismiss() if not content.collide_point(*touch.pos) else None
        )
        
        popup.font_name = 'fonts/TrajanPro-Bold.otf'
        popup.title_size = '20sp'
        popup.title_color = (0.8, 0.8, 0.8, 1)
        popup.title_align = 'center'
        
        popup.open()

    def show_big_map(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.manager.current = 'big_map'

    def show_boss_screen(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.manager.current = 'boss_screen'

    def show_amuletos(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.manager.current = 'amuletos'

    def on_touch(self, instance, touch):
        if self.image.collide_point(touch.x, touch.y):
            # Calcular coordenadas ajustadas
            scale_x = self.image.width / self.image.texture_size[0]
            scale_y = self.image.height / self.image.texture_size[1]
            adjusted_x = (touch.x - self.image.x) / scale_x
            adjusted_y = (touch.y - self.image.y) / scale_y
            
            # Actualizar etiqueta de coordenadas
            self.coords_label.text = f"Coordenadas: ({adjusted_x:.2f}, {adjusted_y:.2f})"
            
            # Verificar zonas
            for zone_id, zone_data in self.zones.items():
                x1, y1, x2, y2 = zone_data['coords']
                if x1 <= adjusted_x <= x2 and y1 >= adjusted_y >= y2:
                    zone_name = zone_data['zona']['en']
                    
                    # Crear pantalla de zona si no existe
                    if zone_name not in self.manager.screen_names:
                        new_zone_screen = ZoneScreen(
                            zone_image=zone_data['image'],
                            zone_data=zone_data,
                            name=zone_name
                        )
                        self.manager.add_widget(new_zone_screen)
                    
                    # Transición a la zona
                    self.manager.current = zone_name
                    break