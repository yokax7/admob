from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.metrics import dp
from kivy.clock import Clock
from kivy.properties import BooleanProperty
from kivy.animation import Animation
from utils.language_manager import language_manager

class LoadingScreen(Screen):
    is_loading = BooleanProperty(False)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.language_manager = language_manager
        self.sprite_images = [
            'assets/loading/1.png',
            'assets/loading/2.png',
            'assets/loading/3.png',
            'assets/loading/4.png',
        ]
        self.current_sprite_index = 0
        self.setup_ui()
        self.update_language()
        self.language_manager.bind(current_language=lambda x, y: self.update_language())
        self.sprite_event = None
        self.loading_animation = None

    def setup_ui(self):
        self.layout = BoxLayout(
            orientation='vertical',
            padding=dp(50),
            spacing=dp(20)
        )

        # Container for sprite with fixed size
        sprite_container = BoxLayout(
            size_hint=(None, None),
            size=(dp(200), dp(200)),
            pos_hint={'center_x': 0.5}
        )

        self.loading_image = Image(
            source=self.sprite_images[self.current_sprite_index],
            fit_mode='contain',
            size_hint=(1, 1)
        )
        sprite_container.add_widget(self.loading_image)

        self.loading_label = Label(
            text=self.language_manager.get_text('loading'),
            font_name='fonts/TrajanPro-Bold.otf',
            font_size='24sp',
            size_hint=(None, None),
            size=(dp(200), dp(50)),
            pos_hint={'center_x': 0.5}
        )

        self.layout.add_widget(sprite_container)
        self.layout.add_widget(self.loading_label)
        self.add_widget(self.layout)

    def update_sprite(self, dt):
        if not self.is_loading:
            return
            
        self.current_sprite_index = (self.current_sprite_index + 1) % len(self.sprite_images)
        self.loading_image.source = self.sprite_images[self.current_sprite_index]

    def start_loading_animation(self):
        self.is_loading = True
        if not self.sprite_event:
            self.sprite_event = Clock.schedule_interval(self.update_sprite, 0.1)
        
        # Pulse animation
        self.loading_animation = Animation(
            opacity=0.5, duration=0.8
        ) + Animation(opacity=1, duration=0.8)
        self.loading_animation.repeat = True
        self.loading_animation.start(self.loading_label)

    def stop_loading_animation(self):
        self.is_loading = False
        if self.sprite_event:
            self.sprite_event.cancel()
            self.sprite_event = None
            
        if self.loading_animation:
            self.loading_animation.cancel(self.loading_label)
            self.loading_animation = None

    def update_language(self, *args):
        self.loading_label.text = self.language_manager.get_text('loading')

    def on_enter(self):
        self.update_language()
        self.start_loading_animation()

    def on_leave(self):
        self.stop_loading_animation()