from kivy.clock import mainthread
from threading import Event
import time
import importlib

class ScreenLoader:
    def __init__(self, screen_manager):
        self.screen_manager = screen_manager
        self.loading_complete = Event()
        
    def prepare_screen_data(self, screen_name, screen_info):
        """Loads and prepares screen data in background"""
        try:
            module = importlib.import_module(screen_info['module'])
            screen_class = getattr(module, screen_info['class'])
            return {
                'screen_class': screen_class,
                'module': module
            }
        except Exception as e:
            print(f"Error preparing screen data: {e}")
            return None
            
    @mainthread
    def create_screen(self, screen_class, params):
        """Creates screen instance in main thread"""
        try:
            return screen_class(**params)
        except Exception as e:
            print(f"Error creating screen: {e}")
            return None