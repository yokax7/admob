from threading import Thread, Event, Lock
from queue import Queue
from kivy.clock import Clock
from functools import partial
import logging
from typing import Callable, Any, Optional

class ThreadManager:
    def __init__(self):
        self.tasks = {}
        self.active_threads = []
        self.result_queue = Queue()
        self._lock = Lock()
        self._stop_event = Event()
        self._logger = logging.getLogger(__name__)

    def start_task(
        self, 
        target_function: Callable, 
        on_complete: Optional[Callable] = None, 
        on_error: Optional[Callable] = None,
        *args, 
        **kwargs
    ) -> int:
        """
        Inicia una tarea en un nuevo hilo
        
        Args:
            target_function: Función a ejecutar
            on_complete: Callback para cuando la tarea termine exitosamente
            on_error: Callback para manejar errores
            *args, **kwargs: Argumentos para target_function
        """
        def thread_target():
            try:
                if self._stop_event.is_set():
                    return

                result = target_function(*args, **kwargs)
                
                if not self._stop_event.is_set():
                    self.result_queue.put((thread.ident, result, None))
                    Clock.schedule_once(
                        partial(self._process_result, thread.ident, on_complete, on_error)
                    )
            except Exception as e:
                self._logger.error(f"Error in thread {thread.ident}: {str(e)}")
                if not self._stop_event.is_set():
                    self.result_queue.put((thread.ident, None, e))
                    Clock.schedule_once(
                        partial(self._process_result, thread.ident, on_complete, on_error)
                    )

        thread = Thread(target=thread_target, daemon=True)
        with self._lock:
            self.active_threads.append(thread)
        thread.start()
        return thread.ident

    def _process_result(
        self, 
        thread_id: int, 
        success_callback: Optional[Callable], 
        error_callback: Optional[Callable],
        dt: float
    ):
        """Procesa el resultado de un hilo"""
        if not self.result_queue.empty():
            tid, result, error = self.result_queue.get()
            if tid == thread_id:
                if error and error_callback:
                    error_callback(error)
                elif success_callback:
                    success_callback(result)
            self._cleanup_thread(thread_id)

    def _cleanup_thread(self, thread_id: int):
        """Limpia un hilo terminado"""
        with self._lock:
            self.active_threads = [t for t in self.active_threads 
                                 if t.ident != thread_id]
            self.tasks.pop(thread_id, None)

    def pause_all(self):
        """Pausa todos los hilos activos"""
        with self._lock:
            self.tasks = {t.ident: t for t in self.active_threads}
            self._logger.debug(f"Paused {len(self.tasks)} threads")

    def resume_all(self):
        """Restaura los hilos pausados"""
        with self._lock:
            dead_threads = []
            for thread_id, thread in self.tasks.items():
                if not thread.is_alive():
                    dead_threads.append(thread_id)
            
            for thread_id in dead_threads:
                self._cleanup_thread(thread_id)
            
            self._logger.debug(f"Resumed {len(self.tasks)} threads")

    def stop_all(self):
        """Detiene todos los hilos y limpia los recursos"""
        self._stop_event.set()
        with self._lock:
            self.active_threads.clear()
            self.tasks.clear()
            while not self.result_queue.empty():
                self.result_queue.get()
        self._logger.info("All threads stopped")

    def get_active_thread_count(self) -> int:
        """Retorna el número de hilos activos"""
        with self._lock:
            return len(self.active_threads)

    def is_task_running(self, thread_id: int) -> bool:
        """Verifica si una tarea específica está en ejecución"""
        with self._lock:
            return any(t.ident == thread_id and t.is_alive() 
                      for t in self.active_threads)