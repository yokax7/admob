# Only keep essential imports at the top
from utils.window_manager import WindowManager

# Initialize window settings before other Kivy imports
if not WindowManager.initialize_window():
    raise SystemExit("Failed to initialize window settings")

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from managers.screen_manager import AppScreenManager
from managers.thread_manager import ThreadManager
from managers.ad_manager import AdManager
from managers.animation_manager import AnimationManager
from utils.music_manager import MusicManager
from utils.version_checker import VersionChecker
from utils.hot_update_manager import HotUpdateManager  # Importar el nuevo HotUpdateManager
from kivy.logger import Logger
from managers.banner_layout_manager import BannerLayout


class HKMAP(App):
    VERSION = "2.0.0"
    GITHUB_VERSION_URL = "https://raw.githubusercontent.com/yokax7/admob/refs/heads/main/version.json"
    # URL para actualizaciones automáticas (archivo JSON con info de actualizaciones)
    HOT_UPDATE_URL = "https://raw.githubusercontent.com/yokax7/admob/refs/heads/main/hot_updates.json"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.screen_manager = AppScreenManager()
        self.thread_manager = ThreadManager()
        self.ad_manager = AdManager.get_instance()
        self.animation_manager = AnimationManager()
        self.music_manager = MusicManager()
        self.version_checker = VersionChecker(self.VERSION, self.GITHUB_VERSION_URL)
        self.hot_update_manager = HotUpdateManager(self.VERSION, self.HOT_UPDATE_URL)  # Inicializar HotUpdateManager
        self._paused = False

    def build(self):
        try:
            from kivy.utils import platform
            if platform == 'android':
                from jnius import autoclass, cast
                # Android-specific code
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                activity = cast('android.app.Activity', PythonActivity.mActivity)
                
                # Create ConsentHelper instance
                ConsentHelper = autoclass('org.yourpackage.ConsentHelper')
                consent_helper = ConsentHelper(activity)
                
                # Request consent update
                consent_helper.requestConsentInfoUpdate()
            else:
                Logger.info('App: Not running on Android, skipping consent flow')
        except Exception as e:
            Logger.error(f'App: Error initializing consent flow: {e}')

        self.container = BoxLayout(orientation='vertical')
        
        # Banner space (fixed 50dp height)
        self.banner_space = BannerLayout()
        
        # Main content
        self.root_layout = BoxLayout(orientation='vertical')
        screen_manager = self.screen_manager.get_screen_manager()
        self.root_layout.add_widget(screen_manager)
        
        self.container.add_widget(self.banner_space)
        self.container.add_widget(self.root_layout)
        
        # Initialize ads with delay
        Clock.schedule_once(lambda dt: self.ad_manager.initialize_ads(), 2)
        
        return self.container

    def on_start(self):
        Clock.schedule_once(lambda dt: self.screen_manager._switch_to_initial_screen(), 0.1)
        # Comprobar actualizaciones de Store (mantener esto si prefieres dar el aviso de ambas)
        Clock.schedule_once(lambda dt: self.version_checker.check_for_updates(), 8)
        # Comprobar actualizaciones automáticas (hot updates) - con un pequeño retraso
        Clock.schedule_once(lambda dt: self.hot_update_manager.check_for_updates(), 5)

    def on_pause(self):
        if self._paused:
            return True
        self._paused = True
        try:
            self.screen_manager.save_current_screen()
            self.animation_manager.pause_all()
            self.thread_manager.pause_all()
            self.ad_manager.handle_pause()
            return True
        except Exception as e:
            Logger.error(f"Error during pause: {e}")
            return False

    def on_resume(self):
        if not self._paused:
            return
        self._paused = False
        try:
            self.screen_manager.restore_saved_screen()
            self.animation_manager.resume_all()
            self.thread_manager.resume_all()
            Clock.schedule_once(lambda dt: self.ad_manager.handle_resume(), 1)
        except Exception as e:
            Logger.error(f"Error during resume: {e}")

    def on_stop(self):
        try:
            self.music_manager.stop_music()
            self.thread_manager.stop_all()
            self.ad_manager.destroy_banner()
        except Exception as e:
            Logger.error(f"Error during stop: {e}")

if __name__ == '__main__':
    HKMAP().run()