from kivy.uix.textinput import TextInput
from kivy.clock import Clock

class TextInputFixed(TextInput):
    def on_focus(self, instance, value, *args):
        if value:
            Clock.schedule_once(self.create_keyboard, .1)
        else:
            self.hide_keyboard()

    def create_keyboard(self, *args):
        self.show_keyboard()

    def remove_focus_decorator(function):
        def wrapper(self, touch):
            if not self.collide_point(*touch.pos):
                self.focus = False
            function(self, touch)
        return wrapper
    
    @remove_focus_decorator
    def on_touch_down(self, touch):
        super().on_touch_down(touch)

    def on_text_validate(self):
        self.focus = True