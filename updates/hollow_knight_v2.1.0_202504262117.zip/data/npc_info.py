npc_info = [    
    {'npc_image_path': 'npc/Iselda_Circle.png', 'popup_image_path': 'npc/iselda_screen.png', 'name': 'Iselda'},
    {'npc_image_path': 'npc/Legeater_Circle.png', 'popup_image_path': 'npc/legeater_screen.png', 'name': 'Legeater'},
    {'npc_image_path': 'npc/Divine_Circle.png', 'popup_image_path': 'npc/divine_screen.png', 'name': 'Divine'},
    {'npc_image_path': 'npc/Grubfather.png', 'popup_image_path': 'npc/grubfather_screen.png', 'name': 'GrubFather'},
    {'npc_image_path': 'npc/Nailsmith_Circle.png', 'popup_image_path': 'npc/nailsmith_screen.png', 'name': 'NailSmith'},
    {'npc_image_path': 'npc/Salubra_Circle.png', 'popup_image_path': 'npc/salubra_screen.png', 'name': 'Salubra'},
    {'npc_image_path': 'npc/Seer_Circle.png', 'popup_image_path': 'npc/seer_screen.png', 'name': 'Seer'},
    {'npc_image_path': 'npc/Sly_Circle.png', 'popup_image_path': 'npc/sly_screen.png', 'name': 'Sly'}
]

    