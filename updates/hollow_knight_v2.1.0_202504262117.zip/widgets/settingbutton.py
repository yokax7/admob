from kivy.uix.widget import Widget
from kivy.uix.image import AsyncImage
from kivy.animation import Animation
from kivy.metrics import dp
from kivy.properties import BooleanProperty, ListProperty, ObjectProperty
from math import cos, sin, pi
from .VolumeControl import VolumeControl
from functools import partial
from kivy.clock import Clock
import time
from kivy.logger import Logger
from managers.dev_manager import DevManager


class SettingsButton(Widget):
    is_open = BooleanProperty(False)
    images = ListProperty([])
    main_image = ObjectProperty(None)
    sub_buttons_active = BooleanProperty(False)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (dp(50), dp(50))
        self.setup_main_image()
        self.setup_volume_control()
        self.setup_sub_images()
        self.bind(pos=self.update_images_pos)
        
        # Variables para activación de modo dev
        self.click_count = 0
        self.last_click_time = 0
    
    def setup_main_image(self):
        self.main_image = AsyncImage(
            source='logos/config.png',
            size_hint=(None, None),
            size=(dp(30), dp(30)),
            fit_mode='contain',
        )
        self.add_widget(self.main_image)
    
    def on_touch_down(self, touch):
        if self.main_image.collide_point(*touch.pos):
            current_time = time.time()
            
            # Reset contador si pasaron más de 2 segundos
            if current_time - self.last_click_time > 2:
                self.click_count = 0
            
            self.last_click_time = current_time
            self.click_count += 1
            
            Logger.debug(f'SettingsButton: Click count: {self.click_count}')
            
            # Activar modo dev después de 10 clicks
            if self.click_count >= 10:
                Logger.info('SettingsButton: Activating dev mode...')
                self.click_count = 0
                self.activate_dev_mode()
                return True
            
            self.toggle_images(touch)
            return True
        return super().on_touch_down(touch)
        
    def activate_dev_mode(self):
        try:
            from kivy.app import App
            app = App.get_running_app()
            dev_manager = DevManager.get_instance()
            
            if dev_manager.dev_mode:
                dev_manager.disable_dev_mode()
            else:
                dev_manager.enable_dev_mode()
                
        except Exception as e:
            Logger.error(f'SettingsButton: Error toggling dev mode: {e}')
    
    def setup_volume_control(self):
        self.volume_control = VolumeControl()
        self.add_widget(self.volume_control)
        
    def setup_sub_images(self):
        image_size = dp(32)
        image_configs = [
            {
                'source': 'logos/language_icon.png',
                'callback': self.show_language_screen
            },
            {
                'source': 'navegacion/volume.png',
                'callback': self.show_volume_control
            },
            {
                'source': 'navegacion/info.png',
                'callback': self.show_info
            }
        ]
        
        self.images.clear()
        
        for config in image_configs:
            img = AsyncImage(
                source=config['source'],
                size_hint=(None, None),
                size=(image_size, image_size),
                fit_mode='contain',
                opacity=0
            )
            
            img.bind(on_touch_down=partial(self.handle_sub_button_touch, callback=config['callback']))
            
            self.images.append(img)
            self.add_widget(img)
            
    def toggle_images(self, touch):
        if self.is_open:
            self.hide_images()
        else:
            self.show_images()
                
    def show_images(self):
        self.is_open = True
        self.sub_buttons_active = False
        radius = dp(80)
        angles = [77, 47, 15]
        
        for i, img in enumerate(self.images):
            angle_rad = angles[i] * pi / 180
            x = self.main_image.x + radius * cos(angle_rad)
            y = self.main_image.y + radius * sin(angle_rad)
            
            anim = Animation(
                pos=(x - img.width/2, y - img.height/2),
                opacity=1,
                duration=0.3,
                t='out_quad'
            )
            if i == len(self.images) - 1:
                anim.bind(on_complete=self.enable_sub_buttons)
            anim.start(img)
    
    def enable_sub_buttons(self, *args):
        self.sub_buttons_active = True
            
    def hide_images(self, *args):
        self.is_open = False
        for img in self.images:
            anim = Animation(
                pos=self.main_image.pos,
                opacity=0,
                duration=0.2,
                t='in_quad'
            )
            anim.start(img)
            
    def update_images_pos(self, *args):
        if self.main_image:
            self.main_image.pos = self.pos
        
        if not self.is_open:
            for img in self.images:
                img.pos = self.pos
                
        if hasattr(self, 'volume_control'):
            self.volume_control.update_layout(self.main_image.x, self.main_image.y)
                
    def on_size(self, *args):
        if self.main_image:
            self.main_image.size = self.size
            
    def show_language_screen(self, instance, touch):
        if instance.collide_point(*touch.pos):
            from kivy.app import App
            app = App.get_running_app()
            app.screen_manager.load_screen('language_selection')
            self.hide_images()
            
    def show_volume_control(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.volume_control.toggle_slider()
            Clock.schedule_once(self.hide_volume_control, 5)
            self.hide_images()
            
    def hide_volume_control(self, dt):
        self.volume_control.toggle_slider()
            
    def show_info(self, instance, touch):
        if instance.collide_point(*touch.pos):
            from kivy.app import App
            app = App.get_running_app()
            app.screen_manager.load_screen('info')
            self.hide_images()
    
    def handle_sub_button_touch(self, instance, touch, callback):
        if self.sub_buttons_active and instance.collide_point(*touch.pos):
            callback(instance, touch)
