from kivy.logger import Logger
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.image import AsyncImage
from kivy.metrics import dp
from kivy.utils import platform
import json
import os
from kivy.core.window import Window

class AchievementManager:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = AchievementManager()
        return cls._instance

    def __init__(self):
        if AchievementManager._instance is not None:
            raise Exception("AchievementManager is a singleton. Use get_instance()")
            
        from utils.language_manager import language_manager
        self.language_manager = language_manager

        # Get proper storage path for each platform
        if platform == 'android':
            try:
                from android.storage import app_storage_path
                storage_path = app_storage_path()
            except ImportError:
                storage_path = os.path.expanduser('~/.hkmap')
        elif platform == 'ios':
            try:
                from pyobjus import autoclass
                NSSearchPathForDirectoriesInDomains = autoclass('NSSearchPathForDirectoriesInDomains')
                storage_path = NSSearchPathForDirectoriesInDomains(9, 1, True).objectAtIndex_(0)
            except ImportError:
                storage_path = os.path.expanduser('~/.hkmap')
        else:  # Desktop platforms
            storage_path = os.path.expanduser('~/.hkmap')
            
        # Create storage directory if it doesn't exist
        self.storage_dir = os.path.join(storage_path, 'achievements')
        os.makedirs(self.storage_dir, exist_ok=True)
        
        self.ACHIEVEMENTS_FILE = os.path.join(self.storage_dir, 'achievements.json')
        
        # Add debug logging
        Logger.info(f'Achievement storage path: {self.storage_dir}')
        Logger.info(f'Achievement file path: {self.ACHIEVEMENTS_FILE}')
        Logger.info(f'Directory exists: {os.path.exists(self.storage_dir)}')
        Logger.info(f'File exists: {os.path.exists(self.ACHIEVEMENTS_FILE)}')
            
        self.achievements = {
            25: {
                'image': 'achievement_25.png',
                'description_key': 'achievement_25',
                'title_key': 'achievement_25_title'
            },
            50: {
                'image': 'achievement_50.png',
                'description_key': 'achievement_50',
                'title_key': 'achievement_50_title'
            },
            100: {
                'image': 'achievement_100.png',
                'description_key': 'achievement_100',
                'title_key': 'achievement_100_title'
            }
        }
        
        self.unlocked_achievements = self._load_achievements()
        Logger.info(f'Loaded achievements: {self.unlocked_achievements}')
        self.achievement_images = []  # Store references to images
        self.achievement_widgets = {}

    def setup_achievement_images(self, parent_widget):
        Logger.info('AchievementManager: Setting up achievement images')
        self.achievement_widgets.clear()
        self.achievement_images.clear()  # Reset list
        
        # Usar tamaño fijo en dp para consistencia
        image_size = dp(55)  # Tamaño fijo para todas las pantallas
        spacing = dp(20)     # Espaciado fijo entre imágenes
        
        for i, (score, data) in enumerate(self.achievements.items()):
            is_unlocked = score in self.unlocked_achievements
            
            achievement_img = AsyncImage(
                source=f'assets/{data["image"]}',
                size_hint=(None, None),
                size=(image_size, image_size),
                fit_mode='cover',
                pos_hint={'right': 0.98 - (i * (image_size + spacing) / Window.width), 'top': 0.98},
                opacity=1.0 if is_unlocked else 0.1
            )
            
            achievement_img.score = score
            achievement_img.achievement_data = data
            achievement_img.is_unlocked = is_unlocked
            achievement_img.bind(on_touch_down=self._on_achievement_click)
            
            self.achievement_widgets[score] = achievement_img
            parent_widget.add_widget(achievement_img)
            self.achievement_images.append(achievement_img)
            Logger.info(f'Added achievement image for score {score}, unlocked: {is_unlocked}')

    def _on_achievement_click(self, instance, touch):
        if instance.collide_point(*touch.pos) and not instance.is_unlocked:
            title = self.language_manager.get_text(instance.achievement_data['title_key'])
            condition = self.language_manager.get_text(f"{instance.achievement_data['description_key']}_condition")
            
            content_label = Label(
                text=condition,
                text_size=(dp(550), None),
                size_hint_y=None,
                halign='center',
                valign='middle',
                padding=(dp(10), dp(10)),
                font_name='fonts/TrajanPro-Bold.otf'  # Add font
            )
            content_label.bind(texture_size=content_label.setter('size'))
            
            popup = Popup(
                title=title,
                content=content_label,
                size_hint=(None, None),
                size=(dp(600), dp(150)),
                auto_dismiss=True,
                title_align='center',
                title_font='fonts/TrajanPro-Bold.otf',
                background_color=[0.1, 0.1, 0.1, 0.7]  # More transparent
            )
            popup.open()

    def check_achievements(self, score):
        Logger.debug(f'AchievementManager: Checking achievements for score {score}')
        for level in sorted(self.achievements.keys()):  # Ordenamos los niveles
            Logger.debug(f'AchievementManager: Checking level {level} (unlocked: {level in self.unlocked_achievements})')
            if score >= level and level not in self.unlocked_achievements:
                Logger.info(f'AchievementManager: Achievement {level} unlocked!')
                self._unlock_achievement(level)

    def _unlock_achievement(self, level):
        if level not in self.unlocked_achievements:
            self.unlocked_achievements.add(level)
            self._save_achievements()
            self._refresh_ui()
            self._show_unlock_popup(level)

    def _refresh_ui(self):
        Logger.info('Refreshing achievement UI')
        for img in self.achievement_images:
            img.opacity = 1.0 if img.score in self.unlocked_achievements else 0.1

    def _verify_save(self):
        try:
            with open(self.ACHIEVEMENTS_FILE, 'r') as f:
                saved = set(json.load(f))
                Logger.info(f'Saved achievements verified: {saved}')
                if saved != self.unlocked_achievements:
                    Logger.error('Save verification failed!')
        except Exception as e:
            Logger.error(f'Save verification error: {e}')

    def backup_achievements(self):
        """Create a backup of achievements"""
        if os.path.exists(self.ACHIEVEMENTS_FILE):
            backup_file = f"{self.ACHIEVEMENTS_FILE}.backup"
            try:
                import shutil
                shutil.copy2(self.ACHIEVEMENTS_FILE, backup_file)
                Logger.info(f'AchievementManager: Backup created at {backup_file}')
            except Exception as e:
                Logger.error(f'AchievementManager: Backup failed: {e}')

    def _load_achievements(self):
        try:
            if os.path.exists(self.ACHIEVEMENTS_FILE):
                with open(self.ACHIEVEMENTS_FILE, 'r') as f:
                    return set(json.load(f))
            return set()
        except Exception as e:
            Logger.error(f'Error loading: {e}')
            return set()

    def _save_achievements(self): 
        try:
            with open(self.ACHIEVEMENTS_FILE, 'w') as f:
                json.dump(list(self.unlocked_achievements), f)
            Logger.info(f'Saved achievements: {self.unlocked_achievements}')
        except Exception as e:
            Logger.error(f'Error saving: {e}')

    def _migrate_old_data(self):
        """Migrate achievements from old location if needed"""
        old_file = 'data/achievements.json'
        if os.path.exists(old_file):
            try:
                with open(old_file, 'r') as f:
                    old_achievements = set(json.load(f))
                    self.unlocked_achievements.update(old_achievements)
                    self._save_achievements()
                # Opcional: mover o eliminar archivo antiguo
                os.rename(old_file, f"{old_file}.migrated")
                Logger.info('Achievement data migrated successfully')
            except Exception as e:
                Logger.error(f'Migration failed: {e}')

    def _show_unlock_popup(self, level):
        """Display achievement unlock popup"""
        try:
            achievement_data = self.achievements[level]
            title = self.language_manager.get_text(achievement_data['title_key'])
            description = self.language_manager.get_text(achievement_data['description_key'])
            
            content_label = Label(
                text=description,
                text_size=(dp(550), None),
                size_hint_y=None,
                halign='center',
                valign='middle',
                padding=(dp(10), dp(10)),
                font_name='fonts/TrajanPro-Bold.otf'
            )
            content_label.bind(texture_size=content_label.setter('size'))
            
            popup = Popup(
                title=title,
                content=content_label,
                size_hint=(None, None),
                size=(dp(600), dp(150)),
                auto_dismiss=True,
                title_align='center',
                title_font='fonts/TrajanPro-Bold.otf',
                background_color=[0.1, 0.1, 0.1, 0.7]
            )
            popup.open()
            Logger.info(f'Achievement popup shown for level {level}')
            
        except Exception as e:
            Logger.error(f'Error showing achievement popup: {e}')