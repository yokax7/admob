from kivy.logger import Logger

class MapCoordinates:
    # Dimensiones del mapa base original
    BASE_MAP_WIDTH = 4000  # Ajusta esto al ancho de tu mapa base
    BASE_MAP_HEIGHT = 2800  # Ajusta esto al alto de tu mapa base
    
    @classmethod
    def pixel_to_relative(cls, x, y):
        """
        Convierte coordenadas de píxeles a coordenadas relativas (0-1)
        Las coordenadas de Leaflet tienen el origen en la esquina superior izquierda
        y las coordenadas Y son negativas hacia abajo
        """
        try:
            # Convertir Y negativo a positivo y ajustar origen
            y_adjusted = abs(y)
            
            # Convertir a coordenadas relativas (0-1)
            rel_x = x / cls.BASE_MAP_WIDTH
            rel_y = y_adjusted / cls.BASE_MAP_HEIGHT
            
            # Asegurar que los valores estén entre 0 y 1
            rel_x = max(0, min(1, rel_x))
            rel_y = max(0, min(1, rel_y))
            
            return rel_x, rel_y
            
        except Exception as e:
            Logger.error(f'MapCoordinates: Error converting coordinates: {e}')
            return 0, 0