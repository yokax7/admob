from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.image import AsyncImage
from kivy.metrics import dp
from kivy.cache import Cache
from kivy.animation import Animation
from kivy.clock import Clock
from functools import lru_cache
import csv
import os
from threading import Thread
from queue import Queue
from widgets.HollowKnightButton import HollowKnightButton
from utils.language_manager import language_manager
from screens.components import BorderedBoxLayout, LoadingSpinner
from kivy.graphics import Color, Rectangle
import json

Cache.register('boss_widgets', limit=50)

class BossScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.language_manager = language_manager
        self.current_boss = None
        self.boss_widgets = {}
        self.data_queue = Queue()
        self.loading_data = False
        self.current_filter = 'main'  # Default filter
        self.setup_ui()
        self._start_data_consumer()
        self.language_manager.bind(current_language=self.on_language_change)

    def setup_ui(self):
        # Main layout
        main_layout = BoxLayout(orientation='horizontal', spacing=dp(10), padding=dp(10))
        
        # Left panel (boss list)
        left_panel = BorderedBoxLayout(orientation='vertical', size_hint_x=0.35)
        self.boss_list_scroll = ScrollView(
            do_scroll_x=False,
            bar_width=dp(10),
            scroll_type=['bars', 'content']
        )
        self.boss_list_layout = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            spacing=dp(5),
            padding=dp(5)
        )
        self.boss_list_layout.bind(minimum_height=self.boss_list_layout.setter('height'))
        self.boss_list_scroll.add_widget(self.boss_list_layout)
        left_panel.add_widget(self.boss_list_scroll)
        
        # Right panel (boss details)
        right_panel = BorderedBoxLayout(orientation='vertical', size_hint_x=0.7, )
        
        # Boss title
        self.title_layout = BorderedBoxLayout(
            size_hint_y=0.1,
            padding=dp(10)
        )
        self.title_label = Label(
            font_name='fonts/TrajanPro-Bold.otf',
            font_size=dp(24),
            halign='center'
        )
        self.title_layout.add_widget(self.title_label)
        
        # Boss image
        self.image_layout = BorderedBoxLayout(size_hint_y=0.5)
        with self.image_layout.canvas.before:
            Color(0.2, 0.2, 0.2, 1)  # Color gris oscuro
            self.rect = Rectangle(size=self.image_layout.size, pos=self.image_layout.pos)

        # Vincular el tamaño y la posición del rectángulo a las propiedades del layout
        self.image_layout.bind(size=self._update_rect, pos=self._update_rect)

        self.boss_image = AsyncImage(
            fit_mode='contain',
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        self.image_layout.add_widget(self.boss_image)

        # Boss description
        self.description_layout = BorderedBoxLayout(
            size_hint_y=0.4,
            padding=dp(15)
        )
        self.description_scroll = ScrollView(
            do_scroll_x=False,
            bar_width=dp(10),
            scroll_type=['bars', 'content']
        )
        self.description_label = Label(
            font_size=dp(18),
            halign='left',
            valign='top',
            size_hint_y=None,
            text_size=(None, None)
        )
        # Bind the label's width to the scroll view for proper text wrapping
        self.description_scroll.bind(
            width=lambda *x: setattr(self.description_label, 'text_size', (self.description_scroll.width - dp(30), None))
        )
        # Bind the label's texture size to its height for proper scrolling
        self.description_label.bind(
            texture_size=lambda *x: setattr(self.description_label, 'height', self.description_label.texture_size[1])
        )
        self.description_scroll.add_widget(self.description_label)
        self.description_layout.add_widget(self.description_scroll)

        # Add components to right panel
        right_panel.add_widget(self.title_layout)
        right_panel.add_widget(self.image_layout)
        right_panel.add_widget(self.description_layout)
        
        # Button layout at the bottom
        button_layout = BoxLayout(
            size_hint_y=0.15,
            padding=[dp(5), dp(5)],
            spacing=dp(10)
        )

        # Filter buttons
        self.main_button = HollowKnightButton(
            text=self.language_manager.get_text('main_bosses'),
            size_hint=(0.25, 1)
        )
        self.main_button.bind(on_press=lambda x: self.filter_bosses('main'))

        self.dlc_button = HollowKnightButton(
            text=self.language_manager.get_text('dlc_bosses'),
            size_hint=(0.25, 1)
        )
        self.dlc_button.bind(on_press=lambda x: self.filter_bosses('dlc'))

        self.dream_button = HollowKnightButton(
            text=self.language_manager.get_text('dream_bosses'),
            size_hint=(0.25, 1)
        )
        self.dream_button.bind(on_press=lambda x: self.filter_bosses('dream'))

        self.return_button = HollowKnightButton(
            text=self.language_manager.get_text('exit'),
            size_hint=(0.25, 1)
        )
        self.return_button.bind(on_press=self.return_to_main)

        button_layout.add_widget(self.main_button)
        button_layout.add_widget(self.dlc_button)
        button_layout.add_widget(self.dream_button)
        button_layout.add_widget(self.return_button)
        
        # Add panels to main layout
        main_layout.add_widget(left_panel)
        main_layout.add_widget(right_panel)
        
        # Create root layout
        root_layout = BoxLayout(orientation='vertical')
        root_layout.add_widget(main_layout)
        root_layout.add_widget(button_layout)
        
        self.add_widget(root_layout)
        
        # Loading spinner
        self.loading_spinner = LoadingSpinner()
        self.add_widget(self.loading_spinner)

    def _update_rect(self, instance, value):
        self.rect.size = instance.size
        self.rect.pos = instance.pos    

    def filter_bosses(self, boss_type):
        if self.current_filter == boss_type:
            return
            
        self.current_filter = boss_type
        self.current_boss = None
        self.reload_bosses()

        # Update button states visually
        buttons = {
            'main': self.main_button,
            'dlc': self.dlc_button,
            'dream': self.dream_button
        }
        
        for btn_type, button in buttons.items():
            button.set_active(btn_type == boss_type)

    @staticmethod
    @lru_cache(maxsize=3)
    def load_boss_data(language):
        try:
            # Load bosses.json
            with open(f'lenguajes/{language}/bosses.json', 'r', encoding='utf-8') as f:
                boss_data = json.load(f)
                
            # Load descriptions
            with open(f'lenguajes/{language}/bosses_descriptions.json', 'r', encoding='utf-8') as f:
                descriptions = json.load(f)
                
            # Transform data to match existing format
            processed_data = []
            for boss in boss_data['bosses']:
                boss_entry = {
                    'nombre': boss['name'],
                    'icono': boss['icon'],
                    'imagen': boss['image'],
                    'tipo': boss['type'],
                    'description_id': boss['description_id'],
                    'descripcion': descriptions.get(boss['description_id'], "No description available.")
                }
                processed_data.append(boss_entry)
                
            return processed_data
        except Exception as e:
            print(f"Error loading boss data: {e}")
            return []

    def _start_data_consumer(self):
        def consume_data(dt):
            try:
                while not self.data_queue.empty():
                    batch_data = self.data_queue.get_nowait()
                    if batch_data:
                        self._create_and_add_boss_widgets(batch_data)
            except Exception as e:
                print(f"Error consuming data: {e}")
        
        Clock.schedule_interval(consume_data, 1/30)

    def _create_and_add_boss_widgets(self, batch_data):
        for row in batch_data:
            if row['tipo'] == self.current_filter:
                boss_item = self._create_boss_item(row)
                if boss_item:
                    self.boss_list_layout.add_widget(boss_item)
                    if not self.current_boss:
                        self.show_boss_details(row)

    def _create_boss_item(self, row):
        try:
            item_layout = BorderedBoxLayout(
                orientation='horizontal',
                size_hint_y=None,
                height=dp(60),
                padding=dp(5),
                spacing=dp(10)
            )
            
            # Icon container to maintain consistent size
            icon_container = BoxLayout(
                size_hint_x=None,
                width=dp(50),
                padding=dp(2)
            )
            
            # Boss icon
            icon = AsyncImage(
                source=row['icono'],
                size_hint=(None, None),
                size=(dp(50), dp(50)),
                fit_mode='contain',
                pos_hint={'center_x': 0.5, 'center_y': 0.5}
            )
            
            icon_container.add_widget(icon)
            
            # Name container for proper text wrapping
            name_container = BoxLayout(
                size_hint_x=1,
                padding=[dp(5), 0]
            )
            
            # Boss name with proper text wrapping
            name_label = Label(
                text=row['nombre'],
                font_name='fonts/TrajanPro-Bold.otf',
                font_size=dp(18),
                halign='center',
                valign='middle',
                text_size=(None, dp(60)),  # Fixed height for vertical alignment
                shorten=True,  # Enable text shortening if too long
                shorten_from='right',
                size_hint_x=1
            )
            
            # Bind the label width to container width for proper text wrapping
            name_container.bind(
                width=lambda *x: setattr(
                    name_label, 
                    'text_size', 
                    (name_container.width, dp(60))
                )
            )
            
            name_container.add_widget(name_label)
            
            item_layout.add_widget(icon_container)
            item_layout.add_widget(name_container)
            
            # Bind touch event
            item_layout.bind(
                on_touch_down=lambda instance, touch, r=row:
                self.show_boss_details(r) if instance.collide_point(*touch.pos) else None
            )
        
            return item_layout
        except Exception as e:
            print(f"Error creating boss item: {e}")
            return None

    def show_boss_details(self, row):
        if self.current_boss == row:
            return
            
        self.current_boss = row
        
        # Animate transition
        fade_out = Animation(opacity=0, duration=0.2)
        fade_in = Animation(opacity=1, duration=0.2)
        
        def update_content(dt):
            self.title_label.text = row['nombre']
            self.boss_image.source = row['imagen']
            self._load_description(row)
            self.description_scroll.scroll_y = 1
            fade_in.start(self.title_layout)
            fade_in.start(self.image_layout)
            fade_in.start(self.description_layout)
            self._animate_boss_image()
        
        fade_out.bind(on_complete=lambda *x: Clock.schedule_once(update_content, 0))
        
        fade_out.start(self.title_layout)
        fade_out.start(self.image_layout)
        fade_out.start(self.description_layout)

    def _animate_boss_image(self):
        # Cancel any existing animation
        if hasattr(self, '_current_animation'):
            self._current_animation.cancel(self.boss_image)
        
        # Create floating animation
        float_up = Animation(
            pos_hint={'center_x': 0.5, 'center_y': 0.56}, 
            duration=1.3, 
            t='out_quad'
        )
        float_down = Animation(
            pos_hint={'center_x': 0.5, 'center_y': 0.49}, 
            duration=1.3, 
            t='in_out_quad'
        )
        
        # Chain animations
        float_sequence = float_up + float_down
        
        # Make it loop forever
        float_sequence.repeat = True
        
        # Store reference to cancel later if needed
        self._current_animation = float_sequence
        
        # Start animation
        float_sequence.start(self.boss_image)    

    def _load_description(self, row):
        try:
            if 'descripcion' in row:
                self.description_label.text = row['descripcion']
            else:
                self.description_label.text = "No description available."
        except Exception as e:
            self.description_label.text = f"Error loading description: {str(e)}"

    def on_pre_enter(self):
        """Called when entering the screen"""
        # Force reload every time
        self.reload_bosses()

    def reload_bosses(self):
        if self.loading_data:
            return
            
        self.loading_data = True
        
        # Clear existing state
        self.current_boss = None
        self.boss_list_layout.clear_widgets()
        self.title_label.text = ""
        self.boss_image.source = ""
        self.description_label.text = ""
        Cache.remove('boss_widgets')
        
        self.loading_spinner.start()
        
        def load_data():
            try:
                # Clear the LRU cache to force reload with new language
                self.load_boss_data.cache_clear()
                boss_data = self.load_boss_data(self.language_manager.current_language)
                if boss_data:
                    self._process_boss_data(boss_data)
                else:
                    print("No boss data loaded")
            except Exception as e:
                print(f"Error loading boss data: {e}")
            finally:
                self.loading_data = False
                Clock.schedule_once(
                    lambda dt: setattr(self.loading_spinner, 'opacity', 0)
                )
        
        Thread(target=load_data, daemon=True).start()

    def _process_boss_data(self, boss_data):
        batch_size = 5
        for i in range(0, len(boss_data), batch_size):
            batch = boss_data[i:i + batch_size]
            self.data_queue.put(batch)
            Clock.schedule_once(lambda dt: None, 1/60)

    def return_to_main(self, instance):
        self.manager.current = 'main'

    def on_language_change(self, *args):
        self.update_texts()
        self.reload_bosses()

    def update_texts(self, *args):
        self.return_button.text = self.language_manager.get_text('exit')
        self.main_button.text = self.language_manager.get_text('main_bosses')
        self.dlc_button.text = self.language_manager.get_text('dlc_bosses')
        self.dream_button.text = self.language_manager.get_text('dream_bosses')
        if self.current_boss:
            self._load_description(self.current_boss)