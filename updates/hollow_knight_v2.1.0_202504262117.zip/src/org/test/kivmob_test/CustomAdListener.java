package org.test.kivmob_test;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.LoadAdError;

public class CustomAdListener extends AdListener {
    @Override
    public void onAdLoaded() {
        // Evento cuando el anuncio se carga
        System.out.println("Ad Loaded");
    }

    @Override
    public void onAdFailedToLoad(LoadAdError error) {
        // Evento cuando el anuncio falla al cargarse
        System.out.println("Ad Failed to Load: " + error.getMessage());
    }

    @Override
    public void onAdOpened() {
        // Evento cuando el anuncio se abre
        System.out.println("Ad Opened");
    }

    @Override
    public void onAdClosed() {
        // Evento cuando el anuncio se cierra
        System.out.println("Ad Closed");
    }

    @Override
    public void onAdClicked() {
        // Evento cuando se hace clic en el anuncio
        System.out.println("Ad Clicked");
    }

    @Override
    public void onAdImpression() {
        // Evento cuando se registra una impresión del anuncio
        System.out.println("Ad Impression");
    }
}