# nuevo archivo: managers/resource_loader.py
from kivy.event import EventDispatcher
from kivy.properties import NumericProperty
from functools import partial
from kivy.clock import Clock

class ResourceLoader(EventDispatcher):
    progress = NumericProperty(0)
    
    def __init__(self):
        super().__init__()
        self._resource_registry = {
            'main': {
                'images': ['navegacion/navmap_{language}.png', 'navegacion/Dream_Wielder.png'],
                'icons': ['navegacion/flecha_izquierda.png', 'navegacion/flecha_derecha.png'],
                'weight': 0.3
            },
            'big_map': {
                'images': ['maps/big_map.png'],
                'data': ['data/locations.json'],
                'weight': 0.5
            },
            'boss_screen': {
                'images': ['bosses/*.png'],
                'data': ['data/boss_info.json'],
                'weight': 0.4
            },
            'zone': {
                'dynamic': True,  # Recursos dinámicos basados en parámetros
                'weight': 0.6
            }
            # Agregar más pantallas según sea necesario
        }
        
    def load_screen_resources(self, screen_name, callback, **kwargs):
        """
        Carga recursos para una pantalla específica
        """
        self.progress = 0
        resources = self._resource_registry.get(screen_name, {})
        
        if not resources:
            callback(True)
            return
            
        def update_progress(progress):
            self.progress = progress
            
        def on_complete(dt):
            callback(True)
            
        # Simular carga de recursos
        total_steps = len(resources.keys()) - 1  # Excluir 'weight'
        if total_steps > 0:
            for i, (resource_type, _) in enumerate(resources.items()):
                if resource_type != 'weight':
                    progress = (i / total_steps) * 100
                    Clock.schedule_once(
                        partial(update_progress, progress), 
                        i * 0.2
                    )
            
            Clock.schedule_once(on_complete, (total_steps + 1) * 0.2)
        else:
            callback(True)

resource_loader = ResourceLoader()