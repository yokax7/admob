from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.scatterlayout import ScatterLayout
from kivy.uix.relativelayout import RelativeLayout
from kivy.uix.image import AsyncImage
from kivy.uix.label import Label
from kivy.metrics import dp
from kivy.clock import Clock
from kivy.properties import BooleanProperty, ListProperty, ObjectProperty
from kivy.animation import Animation
from kivy.core.window import Window, Keyboard
from kivy.cache import Cache
from functools import partial
import json
import os
from kivy.logger import Logger
from screens.components import BorderedBoxLayout
from widgets.HollowKnightButton import HollowKnightButton
from utils.language_manager import language_manager
from managers.icon_cache_manager import IconCacheManager
from utils.map_coordinates import MapCoordinates
from kivy.uix.stencilview import StencilView
from kivy.core.clipboard import Clipboard

# Registrar caché para iconos
Cache.register('map_icons', limit=200)

class MapScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Window.bind(on_keyboard=self.on_keyboard)
        self.BASE_ICON_SIZE = dp(32)
        self.icon_cache = IconCacheManager()
        self.map_loaded = False
        self.setup_ui()
        self.load_checked_icons()
        
    def setup_ui(self):
        # Main Layout
        self.main_layout = BoxLayout(orientation='vertical')
        
        # Top Layout (10% height)
        self.setup_top_layout()
        
        # Content Layout (90% height)
        content_layout = BoxLayout(orientation='horizontal', size_hint_y=0.9)
        
        # Map Layout (90% width)
        self.setup_map_layout()
        
        # Right Layout (10% width)
        self.setup_right_layout()
        
        # Add layouts to content
        content_layout.add_widget(self.map_container)
        content_layout.add_widget(self.right_layout)
        
        # Add all to main layout
        self.main_layout.add_widget(self.top_layout)
        self.main_layout.add_widget(content_layout)
        
        self.add_widget(self.main_layout)
        
        # Iniciar carga de iconos
        Clock.schedule_once(self.load_icons, 0.1)

    def setup_top_layout(self):
        self.top_layout = BorderedBoxLayout(
            orientation='horizontal',
            size_hint_y=0.1,
            padding=dp(10),
            spacing=dp(10)
        )
        
        # Logo
        logo = AsyncImage(
            source='logos/logo_png.png',
            size_hint=(None, 1),
            width=dp(300),
            fit_mode='contain'
        )
        
        # Title
        title = Label(
            text='Hollow Knight Map By Yokax',
            font_name='fonts/TrajanPro-Bold.otf',
            font_size=dp(24),
            size_hint=(1, 1)
        )
        
        # Add coordinates label
        self.coords_label = Label(
            text='Coordinates: (0, 0)',
            font_name='fonts/TrajanPro-Bold.otf',
            font_size=dp(16),
            size_hint=(None, 1),
            width=dp(200)
        )
        
        # Exit Button
        exit_button = HollowKnightButton(
            text='Exit',
            size_hint=(None, 0.8),
            width=dp(100),
            pos_hint={'center_y': 0.5}
        )
        exit_button.bind(on_press=self.return_to_main)
        
        self.top_layout.add_widget(logo)
        self.top_layout.add_widget(title)
        self.top_layout.add_widget(self.coords_label)
        self.top_layout.add_widget(exit_button)

    def setup_map_layout(self):
        self.MAP_WIDTH = 4200
        self.MAP_HEIGHT = 2800
        
        self.map_container = RelativeLayout(size_hint=(0.9, 1))
        self.stencil = StencilView(size_hint=(1, 1))
        self.scatter = ScatterLayout(
            size_hint=(None, None),
            do_scale=True,
            scale_min=0.5,
            scale_max=5,
            do_rotation=False,
            auto_bring_to_front=False
        )
        
        Window.bind(mouse_pos=self.on_mouse_pos)
        
        self.scatter.bind(scale=self._on_scatter_scale)
        
        self.map_image = AsyncImage(
            source='assets/interactive_map.webp',
            size_hint=(None, None),
            fit_mode='cover'
        )
        
        # Bind texture for initial positioning AND icon loading
        self.map_image.bind(
            texture=self._on_texture_loaded,
            size=self._on_map_size_updated  # Add this line
        )
        
        self.center_retries = 0
        self.MAX_RETRIES = 5
        
        self.icons_layout = RelativeLayout(size_hint=(None, None))
        self.scatter.add_widget(self.map_image)
        self.scatter.add_widget(self.icons_layout)
        self.stencil.add_widget(self.scatter)
        self.map_container.add_widget(self.stencil)


    def _on_map_size_updated(self, instance, value):
        if self.map_loaded and hasattr(self, 'icons_data'):
            # Clear existing icons
            self.icons_layout.clear_widgets()
            # Reload all icons with new map dimensions
            for group in self.icons_data['groups']:
                self.load_group_icons(group)

    def _on_texture_loaded(self, instance, value):
        if not value and self.center_retries < self.MAX_RETRIES:
            self.center_retries += 1
            Clock.schedule_once(lambda dt: self._adjust_scatter_size(instance, value), 0.1)
        else:
            self.center_retries = 0
            Clock.schedule_once(lambda dt: self._adjust_scatter_size(instance, value), 0)

    def _adjust_scatter_size(self, instance, value):
        if not value:
            return
            
        w, h = Window.size
        image_ratio = value.width / value.height
        container_ratio = w / h
        
        if image_ratio > container_ratio:
            self.map_image.width = w * 1
            self.map_image.height = (w * 1) / image_ratio
        else:
            self.map_image.height = h * 1
            self.map_image.width = (h * 1) * image_ratio
        
        self.scatter.size = self.map_image.size
        self.icons_layout.size = self.map_image.size
        
        # Center map with animation
        target_pos = (
            (self.map_container.width - self.scatter.width) / 2,
            (self.map_container.height - self.scatter.height) / 2
        )
        
        anim = Animation(pos=target_pos, duration=0.3)
        anim.start(self.scatter)
        self.map_loaded = True

    def _on_scatter_scale(self, instance, value):
        new_size = self.BASE_ICON_SIZE / self.scatter.scale
        for icon_container in self.icons_layout.children:
            if isinstance(icon_container, RelativeLayout):
                old_pos = icon_container.pos
                old_size = icon_container.size[0]  # Store current size before changing
                icon_container.size = (new_size, new_size)
                # Adjust position to maintain centering
                icon_container.pos = (old_pos[0] + (old_size - new_size)/2, 
                                    old_pos[1] + (old_size - new_size)/2)

    def setup_right_layout(self):
        self.right_layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_x=0.1,
            padding=dp(5),
            spacing=dp(5)
        )
        
        # Toggle All Button
        self.toggle_all_button = HollowKnightButton(
            text='Hide All',
            size_hint_y=0.05
        )
        self.toggle_all_button.bind(on_press=self.toggle_all_icons)
        
        # Scroll View para grupos
        scroll_view = ScrollView(
            size_hint=(1, 0.95),
            do_scroll_x=False,
            bar_width=dp(10)
        )
        
        self.groups_layout = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            spacing=dp(10),
            padding=dp(5)
        )
        self.groups_layout.bind(
            minimum_height=self.groups_layout.setter('height')
        )
        
        scroll_view.add_widget(self.groups_layout)
        
        self.right_layout.add_widget(self.toggle_all_button)
        self.right_layout.add_widget(scroll_view)

    def load_icons(self, dt):
        try:
            with open('data/map_icons.json', 'r', encoding='utf-8') as f:
                self.icons_data = json.load(f)
                
            # Cargar grupos de iconos
            for group in self.icons_data['groups']:
                self.add_icon_group(group)
                
        except Exception as e:
            Logger.error(f'MapScreen: Error loading icons: {e}')

    def add_icon_group(self, group):
        # Crear contenedor para el grupo
        group_container = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            height=dp(80),
            spacing=dp(5)
        )
        
        # Icono del grupo
        group_icon = AsyncImage(
            source=group['icon'],
            size_hint=(None, None),
            size=(dp(40), dp(40)),
            pos_hint={'center_x': 0.5}
        )
        
        # Label del grupo
        group_label = Label(
            text=group['name'],
            font_name='fonts/TrajanPro-Bold.otf',
            font_size=dp(20),
            size_hint_y=None,
            height=dp(20)
        )
        
        # Bind para toggle del grupo
        group_icon.bind(
            on_touch_down=partial(self.toggle_group_icons, group['id'])
        )
        
        group_container.add_widget(group_icon)
        group_container.add_widget(group_label)
        
        self.groups_layout.add_widget(group_container)
        
        # Almacenar referencia
        group['icon_widget'] = group_icon
        group['container'] = group_container
        
        # Cargar sub-iconos del grupo
        self.load_group_icons(group)

    def load_group_icons(self, group):
        for icon in group['icons']:
            icon_widget = self.create_map_icon(icon)
            if icon_widget:
                self.icons_layout.add_widget(icon_widget)
                icon['widget'] = icon_widget

    def create_map_icon(self, icon_data):
        try:
            if not self.map_loaded or not self.map_image.texture:
                Logger.warning('MapScreen: Map not fully loaded yet')
                return None

            # Original coordinates from JSON
            map_x = icon_data['position']['x']
            map_y = abs(icon_data['position']['y'])  # Convert negative Y to positive
            
            # Calculate relative positions using proportions
            rel_x = (map_x / self.MAP_WIDTH) * self.map_image.width
            rel_y = (map_y / self.MAP_HEIGHT) * self.map_image.height
            
            

            container = RelativeLayout(
                size_hint=(None, None),
                size=(self.BASE_ICON_SIZE, self.BASE_ICON_SIZE),
                pos=(rel_x - self.BASE_ICON_SIZE/2, rel_y - self.BASE_ICON_SIZE/2)
            )

            icon = AsyncImage(
                source=icon_data['icon'],
                size_hint=(1, 1)
            )

            check = AsyncImage(
                source='assets/icons/check.png',
                size_hint=(0.5, 0.5),
                pos_hint={'right': 1, 'top': 1},
                opacity=0
            )

            container.add_widget(icon)
            container.add_widget(check)

            icon.bind(on_touch_down=partial(self.toggle_icon_check, icon_data['id']))

            if icon_data['id'] in self.checked_icons:
                check.opacity = 1

            return container
                    
        except Exception as e:
            Logger.error(f'MapScreen: Error creating icon: {e}')
            return None
    def update_icons_size(self, instance, value):
        new_size = self.BASE_ICON_SIZE / value
        
        # Update all icons in icons_layout
        for icon_container in self.icons_layout.children:
            icon_container.size = (new_size, new_size)

    def toggle_group_icons(self, group_id, instance, touch):
        if not instance.collide_point(*touch.pos):
            return
            
        group = next((g for g in self.icons_data['groups'] if g['id'] == group_id), None)
        if not group:
            return
            
        # Toggle opacidad del grupo
        target_opacity = 0.3 if group.get('active', True) else 1
        group['active'] = not group.get('active', True)
        
        # Animar icono del grupo
        anim = Animation(opacity=target_opacity, duration=0.3)
        anim.start(group['icon_widget'])
        
        # Toggle visibilidad de sub-iconos
        for icon in group['icons']:
            if 'widget' in icon:
                icon['widget'].opacity = 1 if target_opacity == 1 else 0

    def toggle_all_icons(self, instance):
        show_all = self.toggle_all_button.text == 'Show All'
        
        # Actualizar texto del botón
        self.toggle_all_button.text = 'Hide All' if show_all else 'Show All'
        
        # Toggle todos los grupos
        for group in self.icons_data['groups']:
            group['active'] = show_all
            
            # Animar icono del grupo
            anim = Animation(opacity=1 if show_all else 0.3, duration=0.3)
            anim.start(group['icon_widget'])
            
            # Toggle sub-iconos
            for icon in group['icons']:
                if 'widget' in icon:
                    icon['widget'].opacity = 1 if show_all else 0

    def toggle_icon_check(self, icon_id, instance, touch):
        if not instance.collide_point(*touch.pos):
            return
            
        # Encontrar el check mark
        container = instance.parent
        check = next((c for c in container.children if c.source.endswith('check.png')), None)
        if not check:
            return
            
        # Toggle check
        is_checked = check.opacity == 1
        anim = Animation(opacity=0 if is_checked else 1, duration=0.2)
        anim.start(check)
        
        # Actualizar estado guardado
        if is_checked:
            self.checked_icons.discard(icon_id)
        else:
            self.checked_icons.add(icon_id)
            
        self.save_checked_icons()

    def load_checked_icons(self):
        try:
            if os.path.exists('data/checked_icons.json'):
                with open('data/checked_icons.json', 'r') as f:
                    self.checked_icons = set(json.load(f))
            else:
                self.checked_icons = set()
        except:
            self.checked_icons = set()

    def save_checked_icons(self):
        try:
            with open('data/checked_icons.json', 'w') as f:
                json.dump(list(self.checked_icons), f)
        except Exception as e:
            Logger.error(f'MapScreen: Error saving checked icons: {e}')

    def return_to_main(self, instance):
        self.manager.current = 'main'

    def on_leave(self):
        # Limpiar caché al salir
        self.icon_cache.clear()
        
    def on_mouse_pos(self, window, pos):
        if not self.map_container.collide_point(*pos) or not hasattr(self, 'scatter'):
            return
        
        # Convertir posición del mouse a coordenadas locales del scatter
        local_x = pos[0] - self.map_container.x - self.scatter.x
        local_y = pos[1] - self.map_container.y - self.scatter.y
        
        # Ajustar por el scale del scatter
        scaled_x = local_x / self.scatter.scale
        scaled_y = local_y / self.scatter.scale
        
        # Convertir a coordenadas del mapa
        map_x = int((scaled_x / self.map_image.width) * self.MAP_WIDTH)
        map_y = int(-((scaled_y / self.map_image.height) * self.MAP_HEIGHT))
        
        self.coords_label.text = f'Coordinates: ({map_x}, {map_y})'

    def on_keyboard(self, window, key, scancode, codepoint, modifier):
        if key == Keyboard.keycodes['spacebar']:
            # Extract coordinates from label text
            coords_text = self.coords_label.text
            coords = coords_text.replace('Coordinates: ', '').strip('()')
            x, y = map(int, coords.split(','))
            
            # Format JSON-style coordinates
            json_format = f'"position": {{\n    "x": {x},\n    "y": {y}\n}}'
            
            # Copy to clipboard
            Clipboard.copy(json_format)
            return True
        return False