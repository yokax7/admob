from kivy.utils import platform
from kivy.logger import Logger
from kivy.clock import Clock
from kivmob_mod import TestIds, RewardedListenerInterface, KivMob
from threading import Thread
from functools import partial
from kivy.clock import mainthread
import time

class AdManager:
    _instance = None
    
    @classmethod
    def get_instance(cls):
        if not cls._instance:
            cls._instance = AdManager()
        return cls._instance

    def __init__(self):
        if AdManager._instance:
            raise Exception("Use AdManager.get_instance()")
            
        self.ads = None
        self.banner_active = False
        self.rewarded_loaded = False
        self.interstitial_loaded = False
        self.show_rewarded_next = True  # Flag to alternate between ad types
        #self.app_id = TestIds.APP
        #self.banner_id = TestIds.BANNER
        #self.rewarded_id = TestIds.REWARDED_VIDEO
        #self.interstitial_id = TestIds.INTERSTITIAL
        self.app_id = 'ca-app-pub-8734048675887657~6338661455'
        self.banner_id = 'ca-app-pub-8734048675887657/3070721473'
        self.rewarded_id = 'ca-app-pub-8734048675887657/3040955713'
        self.interstitial_id = 'ca-app-pub-8734048675887657/4258170863'


    def initialize_ads(self):
        """Initialize ads in a background thread"""
        Thread(target=self._initialize_ads_background, daemon=True).start()

    def _initialize_ads_background(self):
        """Background thread for ads initialization"""
        try:
            if platform == 'android':
                self.ads = KivMob(self.app_id)
                Logger.info('AdManager: Initialized successfully')
                # Schedule UI operations on the main thread
                Clock.schedule_once(self._post_init_setup)
        except Exception as e:
            Logger.error(f'AdManager: Init failed: {e}')

    @mainthread
    def _post_init_setup(self, dt):
        """Setup initial ad loads"""
        self._setup_banner()
        self._setup_rewarded()  # Setup rewarded first
        self._setup_interstitial()  # Then setup interstitial
        self._load_initial_ads()

    def _load_initial_ads(self):
        """Load both ad types initially"""
        self._load_rewarded()
        self._load_interstitial()  # Cargar el interstitial inmediatamente

    def _setup_banner(self):
        if self.ads and not self.banner_active:
            try:
                self.ads.new_banner(self.banner_id, top_pos=True)
                self.ads.request_banner()
                # Show banner immediately after request
                self.ads.show_banner()
                self.banner_active = True
                Logger.info('AdManager: Banner setup complete')
            except Exception as e:
                Logger.error(f'AdManager: Banner setup failed: {e}')

    def _setup_rewarded(self):
        if not self.ads:
            return
            
        try:
            class RewardsHandler(RewardedListenerInterface):
                def __init__(self, manager):
                    self.manager = manager

                def on_rewarded(self, reward_type, reward_amount):
                    Logger.info(f"AdManager: Reward earned {reward_type}, {reward_amount}")
                    self.manager.rewarded_loaded = True  # Mark as loaded when reward given
                    # Cargar el rewarded ad de nuevo después de mostrarlo
                    Clock.schedule_once(lambda dt: self.manager._load_rewarded(), 1)
                    # Cargar el interstitial en segundo plano mientras se muestra el rewarded
                    Clock.schedule_once(lambda dt: self.manager._load_interstitial(), 1)

            self.ads.set_rewarded_ad_listener(RewardsHandler(self))
            self._load_rewarded()
            Logger.info('AdManager: Rewarded setup complete')
        except Exception as e:
            Logger.error(f'AdManager: Rewarded setup failed: {e}')

    def _setup_interstitial(self):
        if not self.ads:
            return
        try:
            self._load_interstitial()
            Logger.info('AdManager: Interstitial setup complete')
        except Exception as e:
            Logger.error(f'AdManager: Interstitial setup failed: {e}')

    def _load_rewarded(self):
        if not self.ads:
            return
        try:
            self.rewarded_loaded = False  # Reset flag
            self.ads.load_rewarded_ad(self.rewarded_id)
            self.rewarded_loaded = True  # Set to true when loaded
            Logger.info('AdManager: Rewarded ad loaded successfully')
        except Exception as e:
            Logger.error(f'AdManager: Load rewarded failed: {e}')
            self.rewarded_loaded = False

    def _load_interstitial(self):
        if not self.ads:
            return
        try:
            self.interstitial_loaded = False
            self.ads.load_interstitial(self.interstitial_id)
            # Marcar como cargado cuando esté listo (sin retraso artificial)
            self.interstitial_loaded = True
            Logger.info('AdManager: Interstitial loaded successfully')
        except Exception as e:
            Logger.error(f'AdManager: Load interstitial failed: {e}')
            self.interstitial_loaded = False

    def show_ad(self, callback=None):
        if not self.ads:
            if callback: callback(False)
            return

        try:
            if self.show_rewarded_next:
                if self.rewarded_loaded:
                    self.ads.show_rewarded_ad()
                    self.rewarded_loaded = False
                    # Cargar el rewarded ad de nuevo después de mostrarlo
                    Clock.schedule_once(lambda dt: self._load_rewarded(), 1)
                    # Cargar el interstitial en segundo plano mientras se muestra el rewarded
                    Clock.schedule_once(lambda dt: self._load_interstitial(), 1)
                    if callback: callback(True)
                else:
                    Logger.warning('AdManager: Rewarded not ready, loading...')
                    self._load_rewarded()
                    if callback: callback(False)
            else:
                if self.interstitial_loaded:
                    self.ads.show_interstitial()
                    self.interstitial_loaded = False  # Reset the flag after showing
                    # Cargar el interstitial de nuevo después de mostrarlo
                    Clock.schedule_once(lambda dt: self._load_interstitial(), 1)
                    if callback: callback(True)
                else:
                    Logger.warning('AdManager: Interstitial not ready, loading...')
                    self._load_interstitial()
                    if callback: callback(False)

            self.show_rewarded_next = not self.show_rewarded_next

        except Exception as e:
            Logger.error(f'AdManager: Show ad failed: {e}')
            if callback: callback(False)

    def destroy_banner(self):
        if self.ads:
            self.ads.destroy_banner()
            self.banner_active = False

    def handle_resume(self):
        if self.ads and not self.banner_active:
            self._setup_banner()

    def handle_pause(self):
        if self.ads and self.banner_active:
            self.destroy_banner()