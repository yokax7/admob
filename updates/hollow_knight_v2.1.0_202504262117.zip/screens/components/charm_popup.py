from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.image import AsyncImage
from kivy.metrics import dp
from kivy.animation import Animation
from widgets.HollowKnightButton import HollowKnightButton
import os

__all__ = ['CharmPopup']

class CharmPopup:
    def __init__(self, language_manager):
        self.language_manager = language_manager
        self.current_popup = None
        self.como_conseguir_button = None
        self.close_button = None
        self.current_row = None
        self.button_layout = None

    def show_popup(self, row):
        if self.current_popup is not None and self.current_popup._is_open:
            return

        self.current_row = row
        content = self._create_popup_content(row)
        self.current_popup = Popup(
            title='',
            content=content,
            size_hint=(0.9, 0.9),
            background_color=(0, 0, 0, 0.4),
            auto_dismiss=False
        )

        self.current_popup.bind(
            on_dismiss=lambda instance: setattr(self, 'current_popup', None)
        )
        self.current_popup.open()

    def _create_popup_content(self, row):
        content = BoxLayout(orientation='vertical', padding=dp(0), spacing=dp(0))
        
        title_label = Label(
            text=row['nombre'],
            font_name='fonts/TrajanPro-Bold.otf',
            size_hint_y=None,
            height=dp(40),
            font_size=dp(26)
        )
        content.add_widget(title_label)

        if os.path.exists(row['localizacion_imagen']):
            image = AsyncImage(
                source=row['localizacion_imagen'],
                size_hint=(1,1),
                fit_mode='contain'
            )
            content.add_widget(image)

        self.button_layout = BoxLayout(
            orientation='horizontal',
            size_hint_x=0.7,
            size_hint_y=None,
            height=dp(40),
            spacing=dp(10),
            pos_hint={'x': 0.15, 'y':0},
            opacity=1
        )

        self.como_conseguir_button = HollowKnightButton(
            text=self.language_manager.get_text('obtain'),
            size_hint=(0.1, 0.9),
            font_size=dp(18)
        )
        self.como_conseguir_button.bind(
            on_press=lambda instance: self.show_como_conseguir_popup(row)
        )
        self.como_conseguir_button.bind(
            size=lambda instance, size: setattr(self.como_conseguir_button, 'font_size', min(size[0] * 0.2, dp(18)))
        )
        self.button_layout.add_widget(self.como_conseguir_button)

        close_button = HollowKnightButton(
            text=self.language_manager.get_text('exit'),
            size_hint=(0.1, 0.9)
        )
        close_button.bind(
            on_press=lambda instance: self.current_popup.dismiss()
        )
        close_button.bind(
            size=lambda instance, size: setattr(close_button, 'font_size', min(size[0] * 0.2, dp(18)))
        )
        self.button_layout.add_widget(close_button)

        content.add_widget(self.button_layout)
        return content

    def show_como_conseguir_popup(self, row):
        # Animate buttons to fade out
        fade_out = Animation(opacity=0, duration=0.2)
        fade_out.start(self.button_layout)

        anim = Animation(
            size_hint=(0.4, 0.7),
            pos_hint={'x': 0.01, 'center_y': 0.5},
            duration=0.3,
            transition='out_quad'
        )
        anim.start(self.current_popup)

        content = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(10))
        scroll_view = ScrollView(size_hint=(1, 0.9))

        como_conseguir_text = self._load_como_conseguir_text(row)
        text_label = Label(
            text=como_conseguir_text,
            markup=True,
            size_hint_y=None,
            font_size=dp(18),
            padding=(dp(10), dp(10))
        )
        
        text_label.bind(
            width=lambda *x: setattr(text_label, 'text_size', (text_label.width - dp(20), None))
        )
        text_label.bind(
            texture_size=lambda *x: setattr(text_label, 'height', text_label.texture_size[1])
        )

        scroll_view.add_widget(text_label)
        content.add_widget(scroll_view)

        self.close_button = HollowKnightButton(
            text=self.language_manager.get_text('exit'),
            size_hint=(0.3, 0.18),
            pos_hint={'center_x': 0.5},
            font_size=dp(18)
        )
        content.add_widget(self.close_button)

        new_popup = Popup(
            title="",
            content=content,
            size_hint=(0.6, 0.8),
            background_color=(0, 0, 0, 0.5),
            auto_dismiss=False
        )

        self.close_button.bind(
            on_press=lambda instance: self._close_and_reset(new_popup)
        )

        anim.bind(on_complete=lambda *args: new_popup.open())

    def _load_como_conseguir_text(self, row):
        if 'item' in row:
            charm_id = str(row['item'])
            try:
                from screens.charms.data_loader import CharmDataLoader
                data_loader = CharmDataLoader()
                
                # Load how to obtain data for current language
                como_conseguir = data_loader.load_how_to_obtain_data(self.language_manager.current_language)
                
                # Return the text for this charm's ID
                return como_conseguir.get(charm_id, "No se encontró información sobre cómo conseguir este amuleto.")
                
            except Exception as e:
                print(f"Error loading how to obtain data: {e}")
        
        return "No se encontró información sobre cómo conseguir este amuleto."

    def _close_and_reset(self, new_popup):
        new_popup.dismiss()
        
        # Animate buttons to fade back in
        fade_in = Animation(opacity=1, duration=0.3)
        fade_in.start(self.button_layout)
        
        anim = Animation(
            size_hint=(0.75, 0.9),
            pos_hint={'center_x': 0.5, 'center_y': 0.5},
            duration=0.4,
            transition='out_quad'
        )
        anim.start(self.current_popup)

    def update_texts(self):
        if self.como_conseguir_button:
            self.como_conseguir_button.text = self.language_manager.get_text('obtain')
        if self.close_button:
            self.close_button.text = self.language_manager.get_text('exit')
        if self.current_popup and self.current_row:
            self.current_popup.dismiss()
            self.show_popup(self.current_row)