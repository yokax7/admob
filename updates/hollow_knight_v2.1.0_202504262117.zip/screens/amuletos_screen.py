from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from widgets.HollowKnightButton import HollowKnightButton
from kivy.uix.popup import Popup
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.animation import Animation
from kivy.uix.textinput import TextInput
from widgets.rounded_scroll_view import RoundedScrollView
from kivy.uix.image import AsyncImage
from data.amuletos_info import amuletos_info
import os


class AmuletosScreen(Screen):
    def __init__(self, **kwargs):
        super(AmuletosScreen, self).__init__(**kwargs)
        
        amuletoslayout = BoxLayout(orientation='horizontal', size_hint=(1,1), pos_hint={'x':0,'y':0}, padding=10, spacing=10)
        
        self.image = AsyncImage(source='amuletos_img/amuletos_lista.png', keep_ratio=True, fit_mode='contain', size_hint_y=None)
        
        scroll_view = RoundedScrollView(pos_hint={'x':0,'y':0.1}, size_hint=(1, 0.93), do_scroll_x=False, do_scroll_y=True, always_overscroll=True)
        
        scroll_view.add_widget(self.image)
        amuletoslayout.add_widget(scroll_view)
        
        back_button = HollowKnightButton(text='Regresar', size_hint=(1, 0.1), pos_hint={'x':0, 'y':0})
        back_button.bind(on_press=self.go_back)
        
        self.add_widget(amuletoslayout)
        self.add_widget(back_button)
        
        scroll_view.bind(size=self._update_image_size)
        
        self.zones = amuletos_info

        self.coord_input = TextInput(
            text="Coordenadas: (0, 0)",
            size_hint=(1, 0.1),
            pos_hint={'x': 0.2, "y": 0},
            readonly=True,  # Make it read-only
            multiline=False,  # Single line input
            background_color=(1, 1, 1, 0.5),  # Semi-transparent background
            foreground_color=(0, 0, 0, 1)  # Black text
        )
        self.image.bind(on_touch_down=self.on_touch)

    def _update_image_size(self, instance, value):
        self.image.width = instance.width
        self.image.height = instance.width * (6000 / 750)

    def go_back(self, instance):
        self.manager.current = 'main'

    def on_touch(self, instance, touch):
        if self.image.collide_point(touch.x, touch.y):
            scale_x = self.image.width / self.image.texture_size[0]
            scale_y = self.image.height / self.image.texture_size[1]
            adjusted_x = (touch.x - self.image.x) / scale_x
            adjusted_y = (touch.y - self.image.y) / scale_y
            self.coord_input.text = f"Coordenadas: ({adjusted_x:.2f}, {adjusted_y:.2f})"
       
        for zone_id, zone_data in self.zones.items():
            x1, y1, x2, y2 = zone_data['coords']
            if x1 <= adjusted_x <= x2 and y1 >= adjusted_y >= y2:
                popup = Popup(title=zone_data['title'], size_hint=(0.5, 0.9), pos_hint={'x': 0.25, 'y': 0})
                popup.background_color = (1, 1, 1, 0)
                
                content = FloatLayout()
                
                # Agregar la imagen centrada
                image = AsyncImage(source=zone_data['image'], size_hint=(1, 0.85), pos_hint={'center_x': 0.5, 'top': 1}, fit_mode='contain')
                content.add_widget(image)
                
                # Crear el botón "Como Conseguir"
                como_conseguir_button = HollowKnightButton(
                    text="Como Conseguir // How To Acquire",
                    size_hint=(1, 0.1),
                    pos_hint={'center_x': 0.5, 'y': 0.02},  # Posicionar en la parte inferior
                    #background_color=(0, 0, 0, 0),  # Fondo transparente
                    color=(1, 1, 1, 1),  # Texto blanco
                    font_size='18sp',
                    bold=True
                )
                content.add_widget(como_conseguir_button)
                popup.content = content
                
                popup.bind(on_touch_down=lambda popup, touch: popup.dismiss() if not popup.children[0].collide_point(*touch.pos) else None)
                
                como_conseguir_button.bind(on_press=lambda instance: self.show_como_conseguir(popup, zone_data))

                
                popup.open()
                break

        
    def show_como_conseguir(self, current_popup, zone_data):
        # Move the current popup to the left
        anim = Animation(pos_hint={'x': -0.01}, duration=0.5)
        anim.start(current_popup)
        
        # Create and show the new popup
        new_popup = Popup(title="COMO CONSEGUIR // HOW TO ACQUIRE", size_hint=(0.5, 0.9), pos_hint={'x': 0.5, 'y': 0},auto_dismiss=False)
        new_popup.background_color = (1, 1, 1, 0)
        
        # Create a vertical BoxLayout for the content
        new_content = BoxLayout(orientation='vertical')
        
        # Read the content from the text file
        como_conseguir_text = "No se encontró información sobre cómo conseguir este amuleto."
        if 'como_conseguir' in zone_data and os.path.exists(zone_data['como_conseguir']):
            try:
                with open(zone_data['como_conseguir'], 'r', encoding='utf-8') as file:
                    como_conseguir_text = file.read()
            except Exception as e:
                como_conseguir_text = f"Error al leer el archivo: {str(e)}"
        
        # Create a ScrollView to make the text scrollable if it's too long
        scroll_view = ScrollView(size_hint=(1, 0.9))
        
        # Create a Label with the text content
        text_label = Label(text=como_conseguir_text, 
                        markup=True,
                        size_hint_y=None, 
                        halign='justify',
                        valign='top')
        
        # Bind the label's width to the popup's width
        new_popup.bind(width=lambda instance, width: setattr(text_label, 'text_size', (width * 0.9, None)))
        
        # Bind the label's height to its texture size
        text_label.bind(texture_size=lambda instance, size: setattr(instance, 'height', size[1]))
        text_label.bind(width=lambda instance, width: setattr(instance, 'text_size', (width, None)))
        
        # Add the label to the scroll view
        scroll_view.add_widget(text_label)
        
        # Add the scroll view to the content layout
        new_content.add_widget(scroll_view)
        
        # Create a close button
        close_button = HollowKnightButton(
            text="Cerrar",
            size_hint=(0.6, 0.1),
            pos_hint={'center_x': 0.5},
            #background_color=(0, 0, 0, 0),  # Fondo transparente
            #color=(1, 1, 1, 1),  # Texto blanco
            font_size='18sp',
            bold=True
        )

        new_content.add_widget(close_button)
        
        # Set the content of the new popup
        new_popup.content = new_content
        
        # Bind the close button to dismiss the new popup and reset the position of the first popup
        close_button.bind(on_press=lambda instance: self.close_and_reset(new_popup, current_popup))
        
        # Show the new popup
        new_popup.open()

    def close_and_reset(self, new_popup, current_popup):
        new_popup.dismiss()
        anim = Animation(pos_hint={'x': 0.25}, duration=0.5)
        anim.start(current_popup)