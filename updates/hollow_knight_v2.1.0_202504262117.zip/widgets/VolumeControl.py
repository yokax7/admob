from kivy.uix.widget import Widget
from kivy.uix.slider import Slider
from kivy.properties import NumericProperty
from kivy.metrics import dp
from kivy.animation import Animation
from utils.music_manager import music_manager

class VolumeControl(Widget):
    volume = NumericProperty(1.0)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.setup_volume_controls()
        self.update_layout(1, 0) 
        
    def setup_volume_controls(self):
        # Solo crear el slider de volumen, el ícono lo maneja SettingsButton
        self.volume_slider = Slider(
            size_hint=(None, None),
            size=(dp(120), dp(40)),
            min=0,
            max=1,
            value=self.volume,
            orientation='horizontal',
            opacity=0
        )
        self.volume_slider.bind(value=self.on_volume_change)
        self.add_widget(self.volume_slider)
        
    def on_volume_change(self, instance, value):
        self.volume = value
        music_manager.set_volume(value)
        
    def toggle_slider(self):
        target_opacity = 1 if self.volume_slider.opacity == 0 else 0
        anim = Animation(opacity=target_opacity, duration=0.3)
        anim.start(self.volume_slider)
        
    def update_layout(self, base_x, base_y):
        # Posicionar el slider relativo a la posición base
        self.volume_slider.pos = (base_x + dp(120), base_y)