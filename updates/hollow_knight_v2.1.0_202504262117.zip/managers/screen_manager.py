from kivy.uix.screenmanager import ScreenManager, FadeTransition
from kivy.clock import Clock, mainthread
from kivy.core.window import Window
import importlib
import time
from threading import Event
from utils.language_manager import language_manager
from utils.window_manager import WindowManager
from managers.transition_manager import TransitionManager
from managers.screen_definitions import SCREEN_DEFINITIONS
from managers.screen_cache import ScreenCache
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from utils.bug_counter import BugCounter
from managers.ad_manager import AdManager
from kivy.logger import Logger
from widgets.HollowKnightButton import HollowKnightButton
from kivy.metrics import dp  # Add this import at the top



class AppScreenManager:
    def __init__(self):
        self.sm = ScreenManager(transition=FadeTransition(duration=0.4))
        self.current_screen_name = None
        self.cache = ScreenCache()
        self.is_loading = False
        self._screen_classes = SCREEN_DEFINITIONS
        self._loading_complete = Event()
        self.MIN_LOADING_TIME = 1.5
        self.HEAVY_SCREENS = {'big_map', 'boss_screen', 'amuletos'}
        
        TransitionManager.preload_transitions()
        
        from screens.loading_screen import LoadingScreen
        self.loading_screen = LoadingScreen(name='loading')
        self.sm.add_widget(self.loading_screen)
        
        Window.softinput_mode = "below_target"
        Window.allow_screensaver = True

        self.bug_counter = BugCounter.get_instance()
        self.ad_manager = AdManager.get_instance()
        self.AD_THRESHOLD = 13

    def get_screen_manager(self):
        return self.sm

    @mainthread
    def _switch_screen(self, screen_name, transition_type=None):
        try:
            if not transition_type:
                self._perform_transition(screen_name)
                return
                
            transition = TransitionManager.get_transition(transition_type)
            original_transition = self.sm.transition
            self.sm.transition = transition
            self._perform_transition(screen_name)
            
            Clock.schedule_once(
                lambda dt: setattr(self.sm, 'transition', original_transition),
                transition.duration + 0.1
            )
        except Exception as e:
            print(f"Error switching screen to {screen_name}: {e}")
    
    def _perform_transition(self, screen_name):
        self.sm.current = screen_name
        Clock.schedule_once(self._optimize_after_switch, 0.5)

    def _cleanup_screen(self, screen):
        try:
            if hasattr(screen, 'cleanup'):
                screen.cleanup()
            
            if hasattr(screen, 'canvas'):
                screen.canvas.clear()
                
            for child in screen.walk():
                if hasattr(child, 'texture'):
                    child.texture = None
            
            screen.clear_widgets()
            if hasattr(screen, 'unbind_all'):
                screen.unbind_all()
            
            self._force_gc()
            
        except Exception as e:
            print(f"Error in cleanup_screen: {e}")

    def _remove_screen(self, screen_name):
        try:
            screen = self.sm.get_screen(screen_name)
            self._cleanup_screen(screen)
            self.sm.remove_widget(screen)
        except Exception as e:
            print(f"Error removing screen {screen_name}: {e}")

    def _force_gc(self):
        import gc
        gc.collect()

    def _optimize_after_switch(self, dt):
        WindowManager.update_window()

    def load_screen(self, screen_name, **kwargs):
        if self.is_loading:
            return
            
        # Check bug count before screen change
        if (self.sm.current == 'main' and 
            screen_name != 'loading' and 
            self.bug_counter.get_count() >= self.AD_THRESHOLD):
            self._show_ad_popup()
            return

        self.is_loading = True
        self._loading_complete.clear()
        
        try:
            actual_screen_name = kwargs.get('name', screen_name)
            
            if actual_screen_name in self.sm.screen_names:
                self._handle_existing_screen(actual_screen_name, screen_name)
                return
                
            self._begin_new_screen_load(screen_name, actual_screen_name, kwargs)
            
        except Exception as e:
            print(f"Error in load_screen: {e}")
            self.is_loading = False
            self._loading_complete.set()

    def _handle_existing_screen(self, actual_screen_name, screen_name):
        # Update timestamp when revisiting screen
        self.cache.update_timestamp(actual_screen_name)
        screen_info = self._screen_classes.get(screen_name, {})
        self._switch_screen(
            actual_screen_name, 
            screen_info.get('transition_type')
        )
        self.is_loading = False
        self._loading_complete.set()

    def _begin_new_screen_load(self, screen_name, actual_screen_name, kwargs):
        oldest = self.cache.remove_oldest(self.sm.current)
        if oldest:
            self._remove_screen(oldest)

        if screen_name in self._screen_classes:
            self._switch_screen('loading', FadeTransition(duration=0.2))
            Clock.schedule_once(
                lambda dt: self._continue_screen_load(screen_name, actual_screen_name, kwargs),
                0.3
            )

    def _continue_screen_load(self, screen_name, actual_screen_name, kwargs):
        if hasattr(self.loading_screen, 'start_loading_animation'):
            self.loading_screen.start_loading_animation()
        
        start_time = time.time()
        screen_info = self._screen_classes[screen_name]
        
        min_loading_time = self.MIN_LOADING_TIME * 2 if screen_name in self.HEAVY_SCREENS else self.MIN_LOADING_TIME
        
        if screen_name in self.HEAVY_SCREENS:
            Clock.schedule_once(
                lambda dt: self._create_screen(
                    screen_name, actual_screen_name, kwargs, start_time, min_loading_time
                ),
                0.8
            )
        else:
            self._create_screen(screen_name, actual_screen_name, kwargs, start_time, min_loading_time)

    def _create_screen(self, screen_name, actual_screen_name, kwargs, start_time, min_loading_time):
        try:
            screen_info = self._screen_classes[screen_name]
            module = importlib.import_module(screen_info['module'])
            screen_class = getattr(module, screen_info['class'])
            
            params = screen_info['params'].copy()
            params.update(kwargs)
            
            screen = screen_class(**params)
            self.sm.add_widget(screen)
            self.cache.add_screen(actual_screen_name, time.time())
            
            elapsed_time = time.time() - start_time
            remaining_time = max(0.5, min_loading_time - elapsed_time)
            
            Clock.schedule_once(
                lambda dt: self._complete_transition(actual_screen_name, screen_info.get('transition')),
                remaining_time
            )
            
        except Exception as e:
            print(f"Error creating screen: {e}")
            self.is_loading = False
            self._loading_complete.set()

    def _complete_transition(self, screen_name, transition):
        try:
            if hasattr(self.loading_screen, 'stop_loading_animation'):
                self.loading_screen.stop_loading_animation()
            
            Clock.schedule_once(
                lambda dt: self._switch_screen(screen_name, transition),
                0.2
            )
            
        finally:
            Clock.schedule_once(self._finish_loading, 0.5)

    def _finish_loading(self, dt):
        self.is_loading = False
        self._loading_complete.set()

    def load_screens(self, dt=None):
        self._switch_screen('loading', FadeTransition(duration=0.4))
        Clock.schedule_once(self._switch_to_initial_screen, 1)

    def _switch_to_initial_screen(self, dt=None):
        if language_manager.load_language():
            self.load_screen('main')
        else:
            self.load_screen('language_selection')

    def save_current_screen(self):
        self.current_screen_name = self.sm.current

    def restore_saved_screen(self):
        if self.current_screen_name:
            self.load_screen(self.current_screen_name)

    def _show_ad_popup(self):
        content = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(10))
        
        message = Label(
            text=language_manager.get_text('ad_popup_content'),
            text_size=(dp(550), None),
            size_hint_y=None,
            halign='center',
            valign='middle',
            padding=(dp(10), dp(10)),
            font_name='fonts/TrajanPro-Bold.otf'
        )
        message.bind(texture_size=message.setter('size'))
        
        buttons = BoxLayout(orientation='horizontal', size_hint_y=0.3, spacing=dp(5))
        
        show_ad_btn = HollowKnightButton(
            text=language_manager.get_text('show_ad'),
            size_hint_x=0.5,
            font_name='fonts/TrajanPro-Bold.otf'
        )
        
        exit_btn = HollowKnightButton(
            text=language_manager.get_text('exit'),
            size_hint_x=0.5,
            font_name='fonts/TrajanPro-Bold.otf'
        )
        
        popup = Popup(
            title=language_manager.get_text('ad_popup_title'),
            content=content,
            size_hint=(None, None),
            size=(dp(600), dp(250)),
            auto_dismiss=False,
            title_align='center',
            title_font='fonts/TrajanPro-Bold.otf',
            background_color=[0.1, 0.1, 0.1, 0.7]
        )

        def on_show_ad():
            def ad_callback(success):
                if not success:
                    Logger.warning('Failed to show ad')
                popup.dismiss()
                
            Logger.info('Screen Manager: Attempting to show ad')
            self.ad_manager.show_ad(callback=ad_callback)

        def on_exit():
            Logger.info('Screen Manager: User exited ad popup')
            self.bug_counter.reset()
            popup.dismiss()

        show_ad_btn.bind(on_release=lambda x: on_show_ad())
        exit_btn.bind(on_release=lambda x: on_exit())
        
        buttons.add_widget(show_ad_btn)
        buttons.add_widget(exit_btn)
        content.add_widget(message)
        content.add_widget(buttons)
        
        popup.open()