from threading import Thread
from queue import Queue
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivy.properties import ObjectProperty, BooleanProperty
from kivy.metrics import dp
from kivy.cache import Cache
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle
from widgets.HollowKnightButton import HollowKnightButton
from utils.language_manager import language_manager
from screens.components import CharmWidget, CharmPopup, LoadingSpinner
from .charms.data_loader import CharmDataLoader
from .charms.charm_list import CharmList

# Increased cache sizes
Cache.register('charm_widgets', limit=300)
Cache.register('charm_data', limit=50)

class CharmsApp(Screen):
    content_layout = ObjectProperty(None)
    is_loading = BooleanProperty(False)
    data_queue = Queue()
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.language_manager = language_manager
        self.loading_data = False
        self.charm_widget = CharmWidget(language_manager, self.show_popup)
        self.charm_popup = CharmPopup(language_manager)
        self.loading_spinner = None
        self._pending_updates = set()
        self._scroll_trigger = Clock.create_trigger(self._load_visible_items, timeout=0.1)
        self.data_loader = CharmDataLoader()
        self.setup_ui()
        self._start_data_consumer()
        self.language_manager.bind(current_language=self.on_language_change)

    def setup_ui(self):
        # Main container with background color
        main_layout = BoxLayout(
            orientation='vertical',
            spacing=dp(10),
            padding=dp(10)
        )
        
        with main_layout.canvas.before:
            #Color(0.1, 0.1, 0.1, 1)  # Dark background
            Rectangle(pos=main_layout.pos, size=main_layout.size)
        
        main_layout.bind(pos=self._update_rect, size=self._update_rect)

        self.scrollview = ScrollView(
            size_hint=(1, 0.9),
            do_scroll_x=False,
            do_scroll_y=True,
            bar_width=dp(10),
            scroll_type=['bars', 'content']
        )
        
        # Bind scroll event
        self.scrollview.bind(scroll_y=self._on_scroll)

        self.content_layout = CharmList()
        self.content_layout.bind(
            minimum_height=self.content_layout.setter('height')
        )
        
        self.loading_spinner = LoadingSpinner()
        
        button_layout = BoxLayout(
            size_hint_y=0.12
        )
        self.return_button = HollowKnightButton(
            size_hint=(0.5, 1),
            pos_hint={'center_x': 0.5}
        )
        self.return_button.bind(on_press=self.return_to_main)
        button_layout.add_widget(self.return_button)
        
        self.scrollview.add_widget(self.content_layout)
        main_layout.add_widget(self.scrollview)
        main_layout.add_widget(button_layout)
        self.add_widget(main_layout)
        
        self.update_texts()

    def _update_rect(self, instance, value):
        instance.canvas.before.clear()
        with instance.canvas.before:
            Color(0.1, 0.1, 0.1, 1)
            Rectangle(pos=instance.pos, size=instance.size)

    def _start_data_consumer(self):
        def consume_data(dt):
            try:
                while not self.data_queue.empty() and not self.loading_data:
                    batch_data = self.data_queue.get_nowait()
                    if batch_data:
                        self._create_and_add_widgets(batch_data)
            except Exception as e:
                print(f"Error consuming data: {e}")
        
        Clock.schedule_interval(consume_data, 1/60)

    def _create_and_add_widgets(self, batch_data):
        widgets_to_add = []
        for row in batch_data:
            widget = self.charm_widget.create(row)
            if widget:
                # Remove widget from any existing parent before adding
                if widget.parent:
                    widget.parent.remove_widget(widget)
                widgets_to_add.append(widget)
        
        if widgets_to_add:
            def add_widgets(dt):
                for widget in widgets_to_add:
                    if widget.parent:
                        widget.parent.remove_widget(widget)
                    self.content_layout.add_widget(widget)
            Clock.schedule_once(add_widgets)

    def _on_scroll(self, instance, value):
        self._scroll_trigger()

    def _load_visible_items(self, *args):
        if self.loading_data:
            return
            
        scroll_y = self.scrollview.scroll_y
        viewport_height = self.scrollview.height
        content_height = self.content_layout.height
        
        visible_top = (1 - scroll_y) * (content_height - viewport_height)
        visible_bottom = visible_top + viewport_height
        
        for child in self.content_layout.children:
            if visible_top <= child.y <= visible_bottom:
                if child not in self._pending_updates:
                    self._pending_updates.add(child)
                    Clock.schedule_once(lambda dt, c=child: self._update_widget(c))

    def _update_widget(self, widget):
        if widget in self._pending_updates:
            self._pending_updates.remove(widget)

    def on_pre_enter(self):
        Window.bind(size=self._on_window_resize)
        if not self.content_layout.children:
            self.reload_charms()

    def on_pre_leave(self):
        Window.unbind(size=self._on_window_resize)

    def _on_window_resize(self, instance, value):
        self._scroll_trigger()

    def reload_charms(self):
        if self.loading_data:
            return
            
        self.loading_data = True
        self.is_loading = True
        self.scrollview.scroll_y = 1
        self.content_layout.clear_widgets()
        self._pending_updates.clear()
        
        if self.loading_spinner:
            self.content_layout.add_widget(self.loading_spinner)
            self.loading_spinner.start()
        
        def load_data():
            try:
                charm_data = self.data_loader.load_charm_data(self.language_manager.current_language)
                self._process_charm_data(charm_data)
            finally:
                self.loading_data = False
                self.is_loading = False
                if self.loading_spinner and self.loading_spinner.parent:
                    Clock.schedule_once(
                        lambda dt: self.content_layout.remove_widget(self.loading_spinner)
                    )
        
        Thread(target=load_data, daemon=True).start()

    def _process_charm_data(self, charm_data):
        batch_size = 4
        for i in range(0, len(charm_data), batch_size):
            batch = charm_data[i:i + batch_size]
            self.data_queue.put(batch)
            Clock.schedule_once(lambda dt: None, 1/120)

    def return_to_main(self, instance):
        self.manager.current = 'main'

    def on_language_change(self, *args):
        self.update_texts()
        self.reload_charms()

    def update_texts(self, *args):
        self.return_button.text = self.language_manager.get_text('menu')
        self.charm_popup.update_texts()

    def show_popup(self, row):
        self.charm_popup.show_popup(row)

    def cleanup(self):
        """Called when screen is removed from cache"""
        if self.content_layout:
            self.content_layout.clear_widgets()
        self._pending_updates.clear()
        self.data_queue = Queue()  # Reset queue
        self.loading_data = False
        self.is_loading = False
        
    def on_remove(self):
        """Called when screen is removed from ScreenManager"""
        super().on_remove()
        self.cleanup()