from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, RoundedRectangle, StencilPush, StencilUse, StencilUnUse, StencilPop

class RoundedScrollView(ScrollView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            StencilPush()
            Color(1, 1, 1, 1)  # White background color
            self.rounded_rect = RoundedRectangle(size=self.size, pos=self.pos, radius=[50])
            StencilUse()
        with self.canvas.after:
            StencilUnUse()
            StencilPop()

        self.bind(pos=self.update_shape, size=self.update_shape)

    def update_shape(self, *args):
        self.rounded_rect.size = self.size
        self.rounded_rect.pos = self.pos