from kivy.animation import Animation

class AnimationManager:
    def __init__(self):
        self.animations = []

    def create_animation(self, widget, **kwargs):
        anim = Animation(**kwargs)
        anim.bind(on_complete=lambda *args: self.remove_animation(anim))
        self.animations.append(anim)
        anim.start(widget)
        return anim

    def remove_animation(self, animation):
        if animation in self.animations:
            self.animations.remove(animation)

    def pause_all(self):
        try:
            for anim in self.animations[:]:  # Usar una copia de la lista
                if anim and hasattr(anim, 'stop'):
                    anim.stop(self)
                    setattr(anim, '_paused', True)
        except Exception as e:
            print(f"Error pausing animations: {e}")

    def resume_all(self):
        try:
            for anim in self.animations[:]:  # Usar una copia de la lista
                if anim and getattr(anim, '_paused', False):
                    anim.start(self)
                    setattr(anim, '_paused', False)
        except Exception as e:
            print(f"Error resuming animations: {e}")