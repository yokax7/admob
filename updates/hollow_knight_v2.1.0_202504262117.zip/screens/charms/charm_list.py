from kivy.uix.boxlayout import BoxLayout
from kivy.properties import ObjectProperty
from kivy.metrics import dp

class CharmList(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.size_hint_y = None
        self.spacing = dp(10)
        self.height = dp(100)
        self.bind(
            minimum_height=self.setter('height'),
            children=self._update_height
        )

    def _update_height(self, *args):
        total_height = sum(c.height + self.spacing for c in self.children)
        if total_height > 0:
            self.height = total_height

    def add_widget(self, widget, *args, **kwargs):
        if widget.parent:
            widget.parent.remove_widget(widget)
        super().add_widget(widget, *args, **kwargs)
        self._update_height()

    def remove_widget(self, widget):
        super().remove_widget(widget)
        self._update_height()

    def clear_widgets(self, children=None):
        super().clear_widgets(children)
        self._update_height()