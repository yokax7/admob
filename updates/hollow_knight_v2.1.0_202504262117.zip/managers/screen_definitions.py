

SCREEN_DEFINITIONS = {
    'loading': {
        'module': 'screens.loading_screen', 
        'class': 'LoadingScreen',
        'params': {'name': 'loading'},
        'transition_type': "fade"
    },
    'main': {
        'module': 'screens.main_screen', 
        'class': 'MainScreen',
        'params': {'name': 'main'},
        'transition_type': 'slide_left'
    },
    'language_selection': {
        'module': 'screens.lenguaje_screen', 
        'class': 'LanguageSelectionScreen',
        'params': {'name': 'language_selection'},
        'transition_type': 'fade'
    },
    'info': {
        'module': 'screens.info_screen', 
        'class': 'InfoScreen',
        'params': {'name': 'info'},
        'transition_type': 'slide_left'
    },
    'amuletos': {
        'module': 'screens.amulestos_screen2', 
        'class': 'CharmsApp',
        'params': {'name': 'amuletos'},
        'transition_type': 'slide_up'
    },
    'big_map': {
        'module': 'screens.big_map_screen', 
        'class': 'BigMapScreen',
        'params': {'name': 'big_map'},
        'transition_type': 'slide_right'
    },
    'boss_screen': {
        'module': 'screens.boss_screen', 
        'class': 'BossScreen',
        'params': {'name': 'boss_screen'},
        'transition_type': 'slide_up'
    },
    'zone': {
        'module': 'screens.zone_screen',
        'class': 'ZoneScreen',
        'params': {'name': 'zone'},
        'transition_type': 'fade'
    }
}