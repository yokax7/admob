from kivy.uix.widget import Widget
from kivy.uix.image import AsyncImage
from kivy.properties import StringProperty, ObjectProperty, ListProperty
from kivy.graphics import Rectangle, Color

class ContainedImage(Widget):
    source = StringProperty(None)
    texture = ObjectProperty(None)
    texture_size = ListProperty([0, 0])
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._image = AsyncImage(fit_mode='cover')
        self._image.bind(
            texture=self._update_texture,
            texture_size=self._update_texture_size
        )
        self.bind(size=self._update_rect, pos=self._update_rect)
        
    def _update_texture(self, instance, value):
        self.texture = value
        if value:
            self._update_rect()
            
    def _update_texture_size(self, instance, value):
        self.texture_size = value
            
    def _update_rect(self, *args):
        if not self.texture:
            return
            
        self.canvas.clear()
        with self.canvas:
            Rectangle(
                texture=self.texture,
                pos=self.pos,
                size=self.size
            )
            
    def on_source(self, instance, value):
        self._image.source = value
        
    def collide_point(self, x, y):
        return self.x <= x <= self.x + self.width and self.y <= y <= self.y + self.height