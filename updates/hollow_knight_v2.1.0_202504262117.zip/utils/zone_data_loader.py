import json
import os
from functools import lru_cache

class ZoneDataLoader:
    @staticmethod
    @lru_cache(maxsize=3)
    def load_zones(language):
        try:
            file_path = os.path.join('lenguajes', language, 'zones.json')
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                zones = {}
                for zone_id, metadata in data['metadata'].items():
                    zones[int(zone_id)] = {
                        'coords': metadata['coords'],
                        'image': metadata['image'],
                        'zona': {language: data['names'][zone_id]}
                    }
                return zones
        except Exception as e:
            print(f"Error loading zones: {e}")
            return {}

    @staticmethod
    def load_zone_data(language):
        return ZoneDataLoader.load_zones(language)

    def clear_cache(self):
        self.load_zones.cache_clear()