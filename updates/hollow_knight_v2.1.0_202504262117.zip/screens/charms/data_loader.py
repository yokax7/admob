import json
from functools import lru_cache
from kivy.cache import Cache

class CharmDataLoader:
    @staticmethod
    @lru_cache(maxsize=3)
    def load_charm_data(language):
        cache_key = f'charm_data_{language}'
        cached_data = Cache.get('charm_data', cache_key)
        
        if cached_data:
            return cached_data
            
        try:
            # Load main charm data
            with open(f'lenguajes/{language}/charms.json', 'r', encoding='utf-8') as f:
                charm_data = json.load(f)
            
            # Load how to obtain data
            how_to_obtain = CharmDataLoader.load_how_to_obtain_data(language)
            
            # Process data
            processed_data = []
            for charm in charm_data['charms']:
                charm_id = str(charm['id'])
                charm_entry = {
                    'item': charm['id'],
                    'nombre': charm['name'],
                    'descripcion': charm['description'],
                    'muescas': charm['notches'],
                    'icono': charm['icon'],
                    'muescas_imagen': charm['notches_image'], 
                    'localizacion_imagen': charm['location_image'],
                    'como_conseguir': how_to_obtain.get(charm_id, "Information not available")
                }
                processed_data.append(charm_entry)
                
            sorted_data = sorted(processed_data, key=lambda x: x['item'])
            Cache.append('charm_data', cache_key, sorted_data)
            return sorted_data
            
        except Exception as e:
            print(f"Error loading charm data: {e}")
            return []

    @staticmethod
    @lru_cache(maxsize=3)
    def load_how_to_obtain_data(language):
        try:
            with open(f'lenguajes/{language}/charms_como_conseguir.json', 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading how to obtain data: {e}")
            return {}

    def clear_cache(self):
        self.load_charm_data.cache_clear()
        Cache.remove('charm_data')