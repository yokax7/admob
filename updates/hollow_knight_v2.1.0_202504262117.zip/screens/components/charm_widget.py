from kivy.uix.boxlayout import BoxLayout
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.label import Label
from kivy.uix.image import AsyncImage
from kivy.metrics import dp
from kivy.cache import Cache
from .bordered_box import BorderedBoxLayout

class CharmWidget:
    def __init__(self, language_manager, show_popup_callback):
        self.language_manager = language_manager
        self.show_popup_callback = show_popup_callback

    def create(self, row):
        try:
            cache_key = f"charm_{row['nombre']}_{self.language_manager.current_language}"
            cached_widget = Cache.get('charm_widgets', cache_key)
            if cached_widget:
                return cached_widget

            container = BoxLayout(
                orientation='horizontal',
                size_hint_y=None,
                height=dp(150),
                padding=dp(5),
                spacing=dp(5)
            )

            icon_name_layout = self._create_icon_name_layout(row)
            description_layout = self._create_description_layout(row)
            muescas_layout = self._create_muescas_layout(row)
            
            container.add_widget(icon_name_layout)
            container.add_widget(description_layout)
            container.add_widget(muescas_layout)
            
            Cache.append('charm_widgets', cache_key, container)
            return container
        except Exception as e:
            print(f"Error creating charm widget: {e}")
            return None

    def _create_icon_name_layout(self, row):
        layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_x=0.2,
            padding=dp(5)
        )
        
        icon_container = AnchorLayout(
            size_hint_y=0.7,
            padding=dp(1)
        )
        
        icon = AsyncImage(
            source=row['icono'],
            fit_mode='contain',
            size_hint=(None, None),
            size=(dp(60), dp(60))
        )
        
        icon_container.add_widget(icon)
        layout.add_widget(icon_container)
        
        name_container = BoxLayout(
            size_hint_y=0.3,
            padding=(dp(2), 0)
        )
        
        name_label = Label(
            text=row['nombre'],
            font_name='fonts/TrajanPro-Bold.otf',
            font_size=dp(19),
            halign='center',
            valign='middle'
        )
        
        name_container.bind(
            size=lambda *_: setattr(
                name_label,
                'text_size',
                (name_container.width, name_container.height)
            )
        )
        
        name_container.add_widget(name_label)
        layout.add_widget(name_container)
        
        layout.bind(
            on_touch_down=lambda instance, touch, r=row: 
            self.show_popup_callback(r) if instance.collide_point(*touch.pos) else None
        )
        
        
        return layout

    def _create_description_layout(self, row):
        layout = BorderedBoxLayout(
            size_hint_x=0.6,
            padding=dp(10)
        )
        label = Label(
            text=row['descripcion'],
            font_size=dp(22),
            halign='center',
            valign='middle'
        )
        layout.bind(
            size=lambda *_: setattr(
                label, 
                'text_size', 
                (layout.width - dp(20), layout.height)
            )   
        )
        layout.bind(
            on_touch_down=lambda instance, touch, r=row: 
            self.show_popup_callback(r) if instance.collide_point(*touch.pos) else None
        )
        layout.add_widget(label)
        return layout

    def _create_muescas_layout(self, row):
        layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_x=0.1,
            padding=dp(5)
        )
        
        container = BoxLayout(
            orientation='vertical',
            spacing=dp(1),
            padding=dp(1),
            pos_hint={'x': 0.25}
        )
        
        num_muescas = int(row['muescas'])
        for _ in range(num_muescas):
            muesca_container = BoxLayout(
                size_hint_y=1/num_muescas,
                pos_hint={'center_x': 0.5}
            )
            muesca = AsyncImage(
                source=row['muescas_imagen'],
                fit_mode='contain',
                size_hint=(None, None),
                size=(dp(50), dp(50)),
                pos_hint={'center_x': 0.5, 'center_y': 0.5}
            )
            muesca_container.add_widget(muesca)
            container.add_widget(muesca_container)
            
        layout.add_widget(container)
        return layout