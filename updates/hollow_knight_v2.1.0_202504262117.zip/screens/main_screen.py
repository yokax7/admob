from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.animation import Animation
from widgets.npc_button import NPCButton
from data.npc_info import npc_info
from kivy.uix.popup import Popup
from kivy.uix.image import AsyncImage
import threading
from kivy.clock import Clock
from utils.language_manager import language_manager  # Importar el gestor de idiomas
from utils.music_manager import music_manager
from widgets.settingbutton import SettingsButton
from kivy.metrics import dp
from screens.components.bordered_box import BorderedBoxLayout
from kivy.uix.boxlayout import BoxLayout
from widgets.flying_bug.bug_manager import BugManager
from managers.dev_manager import DevManager  # Añade esta importación
from kivy.logger import Logger
from managers.achievement_manager import AchievementManager
from utils.zone_data_loader import ZoneDataLoader


class MainScreen(Screen):
    def __init__(self, **kwargs):
        super(MainScreen, self).__init__(**kwargs)
        self.language_manager = language_manager 
        self.npc_info = npc_info
        self.zone_loader = ZoneDataLoader()
        self.zones = self.zone_loader.load_zones(self.language_manager.current_language)
        self.current_npc_index = 0
        self.bug_manager = BugManager(self)
        self.bug_count = 0
        self.achievement_images = {}
        self.dev_manager = DevManager.get_instance()
        self.achievement_manager = AchievementManager.get_instance()

        # Add bug counter instance
        from utils.bug_counter import BugCounter
        self.bug_counter = BugCounter.get_instance()
        # Only bind to observe changes, don't increment here
        self.bug_counter.bind(count=self._on_count_changed)

        self.setup_ui()
        threading.Thread(target=self.load_resources_in_background).start()
       
    

    def _on_count_changed(self, instance, value):
        """Only update UI when count changes"""
        self.counter_label.text = str(value)
        self.achievement_manager.check_achievements(value)



    def setup_ui(self):
        # Layout principal horizontal
        main_layout = BoxLayout(orientation='horizontal')
        
        # Layout izquierdo (15%)
        self.left_layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_x=0.12
        )
        
        # Sub-layouts izquierdos
        self.navigation_layout = BoxLayout(
            orientation='vertical',
            size_hint_y=0.75
        )
        
        self.settings_layout = BoxLayout(
            orientation='vertical',
            size_hint_y=0.25
        )
        
        # Layout central (70%)
        self.center_layout = BorderedBoxLayout(
            size_hint_x=0.75
        )
        
        # Layout derecho (15%)
        self.right_layout = BorderedBoxLayout(
            orientation='vertical',
            size_hint_x=0.12
        )
        
        # Agregar sub-layouts al layout izquierdo
        self.left_layout.add_widget(self.navigation_layout)
        self.left_layout.add_widget(self.settings_layout)
        
        # Agregar los tres layouts principales
        main_layout.add_widget(self.left_layout)
        main_layout.add_widget(self.center_layout)
        main_layout.add_widget(self.right_layout)
        
        # Crear label para coordenadas
        self.coords_label = Label(
            text="",
            size_hint=(None, None),
            size=(dp(200), dp(30)),
            pos_hint={'center_x': 0.5, 'y': 0},
            color=(1, 1, 1, 0.8)
        )
        
        self.add_widget(main_layout)
       #self.add_widget(self.coords_label)
        self.setup_main_image()

    def setup_main_image(self):
        from kivy.uix.relativelayout import RelativeLayout
        from widgets.image_container import ContainedImage

        # Crear un RelativeLayout para contener la imagen y los elementos superpuestos
        self.main_content = RelativeLayout()
        
        # Configurar la imagen principal
        self.image = ContainedImage(
            size_hint=(1, 1)
        )
        self.image.bind(on_touch_down=self.on_touch)
        self.image.bind(on_touch_move=self.update_coordinates)
        
        # Agregar la imagen al RelativeLayout
        self.main_content.add_widget(self.image)
        
        # Agregar el contador
        self.counter_label = Label(
            text="0",
            font_name='fonts/TrajanPro-Bold.otf',
            font_size='24sp',
            size_hint=(None, None),
            size=(dp(100), dp(50)),
            pos_hint={'right': 0.98, 'y': 0}
        )
        self.main_content.add_widget(self.counter_label)
        
        # Agregar el RelativeLayout al center_layout
        self.center_layout.add_widget(self.main_content)

        # Configurar controles de desarrollador
        self.dev_input = self.dev_manager.setup_dev_controls(
            'main_screen',
            self.main_content,
            self._on_dev_input
        )

        # Configurar los logros después de crear main_content
        self.achievement_manager.setup_achievement_images(self.main_content)

    def update_coordinates(self, instance, touch):
        if self.image.collide_point(touch.x, touch.y):
            scale_x = self.image.width / self.image.texture_size[0]
            scale_y = self.image.height / self.image.texture_size[1]
            adjusted_x = (touch.x - self.image.x) / scale_x
            adjusted_y = (touch.y - self.image.y) / scale_y
            self.coords_label.text = f"Coordenadas: ({adjusted_x:.2f}, {adjusted_y:.2f})"

    def on_pre_enter(self):
        super().on_pre_enter()
        language = self.language_manager.current_language
        # Reload zones when language changes
        self.zones = self.zone_loader.load_zones(language)
        map_image_source = f'lenguajes/{language}/navmap_{language}.png'
        self.image.source = map_image_source
        music_manager.play_background_music()
        self.bug_manager.start()

    def on_pre_leave(self):
        super().on_pre_leave()
        self.bug_manager.stop()
        self.bug_counter.reset()
        self.counter_label.text = "0"

    def load_resources_in_background(self):
        Clock.schedule_once(self.load_images_in_ui, 0.5)

    def load_images_in_ui(self, *args):
        self._setup_navigation_elements()
        self._setup_settings_button()
        self._setup_right_layout_icons()

    def _setup_navigation_elements(self):
        from kivy.uix.relativelayout import RelativeLayout
    
        # Create a RelativeLayout for circle and NPC button
        circle_container = RelativeLayout(
            size_hint=(0.8, 0.2),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # Flechas
        self.left_arrow = AsyncImage(
            source='navegacion/flecha_izquierda.png',
            size_hint=(0.8, 0.2),
            pos_hint={'center_x': 0.5, 'top': 1}
        )
        self.right_arrow = AsyncImage(
            source='navegacion/flecha_derecha.png',
            size_hint=(0.8, 0.2),
            pos_hint={'center_x': 0.5, 'y': 0}
        )
        
        # Círculo
        self.circle = AsyncImage(
            source='navegacion/Dream_Wielder.png',
            size_hint=(1, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # NPC Button
        self.npc_button = NPCButton(
            npc_image_path=self.npc_info[self.current_npc_index]['npc_image_path'],
            size_hint=(1, 1),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        
        # Add circle and NPC button to container
        circle_container.add_widget(self.circle)
        circle_container.add_widget(self.npc_button)  # Added last = appears on top
        
        # Agregar elementos al navigation layout
        self.navigation_layout.add_widget(self.left_arrow)
        self.navigation_layout.add_widget(circle_container)
        self.navigation_layout.add_widget(self.right_arrow)

        # Bind events
        self.left_arrow.bind(on_touch_down=self.show_previous_npc)
        self.right_arrow.bind(on_touch_down=self.show_next_npc)
        self.npc_button.bind(on_press=lambda instance: self.show_npc_popup(self.npc_info[self.current_npc_index]))
        

        # Animaciones
        self._start_circle_animation()
        self._setup_arrow_animations()

    def _start_circle_animation(self):
        anim = Animation(opacity=0.2, duration=2) + Animation(opacity=1, duration=2)
        anim.repeat = True
        anim.start(self.circle)

    def _setup_arrow_animations(self):
        def on_arrow_press(arrow, touch):
            if arrow.collide_point(*touch.pos):
                Animation(opacity=0.5, duration=0.1).start(arrow)

        def on_arrow_release(arrow, touch):
            if arrow.collide_point(*touch.pos):
                Animation(opacity=1, duration=0.2).start(arrow)

        for arrow in [self.left_arrow, self.right_arrow]:
            arrow.bind(on_touch_down=on_arrow_press)
            arrow.bind(on_touch_up=on_arrow_release)

    def _setup_settings_button(self):
        settings_button = SettingsButton()
        self.settings_layout.add_widget(settings_button)

    def _setup_right_layout_icons(self):
        
        from kivy.uix.image import AsyncImage
        from kivy.metrics import dp

        # Clear right layout
        self.right_layout.clear_widgets()

        # Create icons with fixed size_hint and vertical positioning
        icons_data = [
            ('logos/boss_icon.png', 'boss_icon', {'center_x': 0.5, 'top': 1}),
            ('navegacion/Scroll_Map.png', 'map_icon', {'center_x': 0.5, 'center_y': 0.5}),
            ('navegacion/anmuletos.png', 'amuletos_icon', {'center_x': 0.5, 'y': 0})
        ]

        for source, name, pos in icons_data:
            icon = AsyncImage(
                source=source,
                size_hint=(0.8, 0.2),
                pos_hint=pos,
                fit_mode='contain'
            )
            setattr(self, name, icon)
            icon.bind(on_touch_down=self.on_icon_press)
            self.right_layout.add_widget(icon)

    def on_icon_press(self, instance, touch):
        if instance.collide_point(*touch.pos):
            # Bounce animation using size_hint
            orig_size = instance.size_hint
            anim = (
                Animation(size_hint=(0.7, 0.15), duration=0.1) + 
                Animation(size_hint=(0.8, 0.2), duration=0.1)
            )
            anim.start(instance)
            
            if instance == self.map_icon:
                Clock.schedule_once(lambda dt: self.show_big_map(instance, touch), 0.2)
            elif instance == self.boss_icon:
                Clock.schedule_once(lambda dt: self.show_boss_screen(instance, touch), 0.2)
            elif instance == self.amuletos_icon:
                Clock.schedule_once(lambda dt: self.show_amuletos(instance, touch), 0.2)

    def show_previous_npc(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.current_npc_index = (self.current_npc_index - 1) % len(self.npc_info)
            self._update_npc_button()

    def show_next_npc(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.current_npc_index = (self.current_npc_index + 1) % len(self.npc_info)
            self._update_npc_button()

    def _update_npc_button(self):
        npc_info = self.npc_info[self.current_npc_index]
        self.npc_button.update_image(npc_info['npc_image_path'])
        Animation(opacity=0, duration=0.3).start(self.npc_button)
        Animation(opacity=1, duration=0.3).start(self.npc_button)

    def show_npc_popup(self, npc_info):
        from kivy.uix.scrollview import ScrollView
        from kivy.uix.boxlayout import BoxLayout
        from kivy.core.window import Window
        
        POPUP_WIDTH = Window.width * 0.2
        POPUP_HEIGHT = Window.height * 0.85
        BASE_IMAGE_HEIGHT = dp(400)  # Fixed initial height
        
        popup = Popup(
            title=npc_info['name'],
            size_hint=(0.5, 0.9),
            background_color=(0, 0, 0, 1),
            title_font='fonts/TrajanPro-Bold.otf',
            title_align='center',
            title_size='20sp',
            pos_hint={'x': 0.25, 'y': 0.0}
        )

        # Container with fixed initial size
        container = BoxLayout(
            orientation='vertical', 
            size_hint_y=None,
            height=BASE_IMAGE_HEIGHT
        )
        
        # Image with fixed initial size
        content = AsyncImage(
            source=npc_info['popup_image_path'],
            size_hint_y=None,
            height=BASE_IMAGE_HEIGHT,
            fit_mode='contain',
        )
        
        def on_texture(instance, value):
            if not content.texture:
                return
                
            # Calculate dimensions based on texture ratio
            texture_ratio = content.texture.width / content.texture.height
            popup_ratio = POPUP_WIDTH / POPUP_HEIGHT
            
            if (texture_ratio > popup_ratio):
                # Wide image
                content.height = BASE_IMAGE_HEIGHT
            else:
                # Tall image
                content.height = BASE_IMAGE_HEIGHT * 1 / texture_ratio
                
            container.height = content.height

        # Bind only to texture to avoid multiple triggers
        content.bind(texture=on_texture)
        def on_popup_dismiss(instance):
            content.unbind(texture=on_texture)
        
        popup.bind(on_dismiss=on_popup_dismiss)
        
        container.add_widget(content)
        scroll = ScrollView(size_hint=(1, 1))
        scroll.add_widget(container)
        popup.content = scroll
        popup.open()

    def update_image_size(self, *args):
            self.scatter.size = self.width, self.height
            self.image.size = self.width, self.height    

    def show_big_map(self, instance, touch):
        if instance.collide_point(*touch.pos):
            from kivy.app import App
            app = App.get_running_app()
            app.screen_manager.load_screen('big_map')

    def show_boss_screen(self, instance, touch):
        if instance.collide_point(*touch.pos):
            from kivy.app import App
            app = App.get_running_app()
            app.screen_manager.load_screen('boss_screen')

    def show_amuletos(self, instance, touch):
        if instance.collide_point(*touch.pos):
            from kivy.app import App
            app = App.get_running_app()
            app.screen_manager.load_screen('amuletos')

    def on_touch(self, instance, touch):
        if self.image.collide_point(touch.x, touch.y):
            scale_x = self.image.width / self.image.texture_size[0]
            scale_y = self.image.height / self.image.texture_size[1]
            adjusted_x = (touch.x - self.image.x) / scale_x
            adjusted_y = (touch.y - self.image.y) / scale_y
            
            self.coords_label.text = f"Coordenadas: ({adjusted_x:.2f}, {adjusted_y:.2f})"
            
            for zone_id, zone_data in self.zones.items():
                x1, y1, x2, y2 = zone_data['coords']
                if x1 <= adjusted_x <= x2 and y1 >= adjusted_y >= y2:
                    from kivy.app import App
                    app = App.get_running_app()
                    screen_name = f"zone_{zone_id}"
                    
                    # Create zone data in expected format
                    formatted_zone_data = {
                        'image': zone_data['image'],
                        'zona': zone_data['zona']
                    }
                    
                    app.screen_manager.load_screen(
                        'zone',
                        name=screen_name,
                        zone_image=zone_data['image'],
                        zone_data=formatted_zone_data
                    )
                    break

    def _on_dev_input(self, instance):
        try:
            new_value = int(instance.text)
            self.bug_count = new_value
            self.counter_label.text = str(new_value)
            self.achievement_manager.check_achievements(new_value)
        except ValueError:
            Logger.error("MainScreen: Invalid input value")

    def on_leave(self):
        super().on_leave()
        self.dev_manager.cleanup_screen('main_screen')

    def _show_dev_input(self):
        from kivy.uix.textinput import TextInput
        from kivy.metrics import dp
        from kivy.logger import Logger
        
        Logger.info('MainScreen: Showing dev input')
        
        if not hasattr(self, 'dev_input'):
            # Crear el input de desarrollador si no existe
            self.dev_input = TextInput(
                size_hint=(None, None),
                size=(dp(100), dp(40)),
                pos_hint={'right': 0.8, 'top': 0.9},
                multiline=False,
                input_filter='int'
            )
            self.dev_input.bind(on_text_validate=self._on_dev_input)
            self.main_content.add_widget(self.dev_input)
            Logger.info('MainScreen: Dev input created')
        else:
            # Alternar visibilidad si ya existe
            self.dev_input.opacity = 1.0 if self.dev_input.opacity == 0 else 0
            Logger.info(f'MainScreen: Dev input visibility toggled to {self.dev_input.opacity}')

