from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image

class NPCButton(ButtonBehavior, Image):
    def __init__(self, npc_image_path, **kwargs):
        super().__init__(**kwargs)
        self.source = npc_image_path
        self.size_hint =self. size_hint
        self.pos_hint = self.pos_hint

    def update_image(self, new_image_path):
        """Actualiza la imagen del botón"""
        self.source = new_image_path    