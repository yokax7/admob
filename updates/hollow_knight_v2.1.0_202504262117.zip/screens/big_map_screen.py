from kivy.uix.screenmanager import Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.scatter import Scatter
from kivy.uix.image import AsyncImage
from widgets.HollowKnightButton import HollowKnightButton
from utils.language_manager import language_manager

class BigMapScreen(Screen):
    def __init__(self, **kwargs):
        super(BigMapScreen, self).__init__(**kwargs)
        self.language_manager = language_manager
        layout = FloatLayout(size_hint=(1,1))
        self.add_widget(layout)
        
        self.scatter = Scatter(do_rotation=False, do_translation=True, do_scale=True, size_hint=(1, 1), pos=(0, 0))
        layout.add_widget(self.scatter)
        
        self.image = AsyncImage(source='navegacion/big_map.png', fit_mode='contain')
        self.scatter.add_widget(self.image)
        
        self.back_button = HollowKnightButton(size_hint=(0.15, 0.1), pos_hint={"x": 0.02, "y": 0})
        self.back_button.bind(on_press=self.go_back)
        self.add_widget(self.back_button)
        
        self.bind(size=self.update_image_size)
        
        self.update_language()
        language_manager.bind(current_language=lambda x, y: self.update_language())
        
    def update_image_size(self, *args):
        self.scatter.size = self.width, self.height
        self.image.size = self.width, self.height    
        
    def go_back(self, instance):
        self.manager.current = 'main'

    def change_language(self, lang):
        def change(instance):
            self.language_manager.set_language(lang)
            self.update_language()
        return change    

    def update_language(self, *args):
        self.back_button.text = self.language_manager.get_text('exit')

    def on_enter(self):
        self.update_language()
        